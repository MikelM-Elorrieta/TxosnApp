package Menu;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Comisarios.VistaComisarios;
import Eventos.VistaEventos;
import Inventario.VistaInventario;

import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaMenu extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaMenu frame = new VistaMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaMenu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton btnComisarios = new JButton("COMISARIOS");
		GridBagConstraints gbc_btnComisarios = new GridBagConstraints();
		gbc_btnComisarios.insets = new Insets(0, 0, 5, 5);
		gbc_btnComisarios.gridx = 1;
		gbc_btnComisarios.gridy = 1;
		contentPane.add(btnComisarios, gbc_btnComisarios);
		
		JButton btnInventario = new JButton("INVENTARIO");
		GridBagConstraints gbc_btnInventario = new GridBagConstraints();
		gbc_btnInventario.insets = new Insets(0, 0, 5, 5);
		gbc_btnInventario.gridx = 2;
		gbc_btnInventario.gridy = 1;
		contentPane.add(btnInventario, gbc_btnInventario);
		
		JButton btnEventos = new JButton("EVENTOS");
		GridBagConstraints gbc_btnEventos = new GridBagConstraints();
		gbc_btnEventos.insets = new Insets(0, 0, 5, 5);
		gbc_btnEventos.gridx = 3;
		gbc_btnEventos.gridy = 1;
		contentPane.add(btnEventos, gbc_btnEventos);
		
		//Boton Comisarios
		btnComisarios.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaComisarios vistaComisarios = new VistaComisarios();
				vistaComisarios.setVisible(true);
				dispose();
			}
			
		});
		
		
		//Boton Inventario
		btnInventario.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaInventario vistaInventario = new VistaInventario();
				vistaInventario.setVisible(true);
				dispose();
				
			}
			
		});
		
		
		//Boton Eventos
		btnEventos.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaEventos vistaEventos = new VistaEventos();
				vistaEventos.setVisible(true);
				dispose();
				
			}
			
		});
	}

}
