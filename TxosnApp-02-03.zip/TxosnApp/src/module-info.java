/**
 * 
 */
/**
 * 
 */
module TxosnApp {
	requires java.desktop;
	requires java.sql;
	
}

