package Inventario;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Menu.VistaMenu;

import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaInventario extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaInventario frame = new VistaInventario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaInventario() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton btnAlcohol = new JButton("BEBIDAS ALCOHOLICAS");
		GridBagConstraints gbc_btnAlcohol = new GridBagConstraints();
		gbc_btnAlcohol.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnAlcohol.insets = new Insets(0, 0, 5, 5);
		gbc_btnAlcohol.gridx = 2;
		gbc_btnAlcohol.gridy = 1;
		contentPane.add(btnAlcohol, gbc_btnAlcohol);
		
		JButton btnRefrescos = new JButton("REFRESCOS");
		GridBagConstraints gbc_btnRefrescos = new GridBagConstraints();
		gbc_btnRefrescos.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnRefrescos.insets = new Insets(0, 0, 5, 5);
		gbc_btnRefrescos.gridx = 2;
		gbc_btnRefrescos.gridy = 3;
		contentPane.add(btnRefrescos, gbc_btnRefrescos);
		
		JButton btnPrendas = new JButton("PRENDAS");
		GridBagConstraints gbc_btnPrendas = new GridBagConstraints();
		gbc_btnPrendas.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnPrendas.insets = new Insets(0, 0, 5, 5);
		gbc_btnPrendas.gridx = 2;
		gbc_btnPrendas.gridy = 5;
		contentPane.add(btnPrendas, gbc_btnPrendas);
		
		JButton btnMaterial = new JButton("MATERIAL");
		GridBagConstraints gbc_btnMaterial = new GridBagConstraints();
		gbc_btnMaterial.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnMaterial.insets = new Insets(0, 0, 5, 5);
		gbc_btnMaterial.gridx = 2;
		gbc_btnMaterial.gridy = 7;
		contentPane.add(btnMaterial, gbc_btnMaterial);
		
		JButton btnVolver = new JButton("VOLVER");
		GridBagConstraints gbc_btnVolver = new GridBagConstraints();
		gbc_btnVolver.gridx = 4;
		gbc_btnVolver.gridy = 8;
		contentPane.add(btnVolver, gbc_btnVolver);
		
		btnAlcohol.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaAlcoholes alcoholes = new VistaAlcoholes();
				alcoholes.setVisible(true);
				dispose();
				
			}
			
		});
		
		btnRefrescos.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaRefrescos refrescos = new VistaRefrescos();
				refrescos.setVisible(true);
				dispose();
				
			}
			
		});
		
		btnPrendas.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaPrendas prendas = new VistaPrendas();
				prendas.setVisible(true);
				dispose();
				
			}
			
		});
		
		btnVolver.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaMenu menu = new VistaMenu();
				menu.setVisible(true);
				dispose();
				
			}
			
		});
	}

}
