package Eventos;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import SQL.Conexion;

public class VistaAñadirEvento extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private Color colorFondo = new Color(240, 240, 240);
    private Font fuenteTitulos = new Font("Arial", Font.BOLD, 24);
    private Font fuenteNormal = new Font("Arial", Font.PLAIN, 16);

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    VistaAñadirEvento frame = new VistaAñadirEvento();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public VistaAñadirEvento() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        // Configuración del panel principal
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new GridBagLayout());
        
        // Configuración de la barra de menú
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        
        JMenuItem añadirEvento = crearItemMenu("AÑADIR EVENTO");
        JMenuItem mostrarEventos = crearItemMenu("MOSTRAR EVENTOS");
        
        menuBar.add(añadirEvento);
        menuBar.add(mostrarEventos);
        
        // Listeners de los items del menú
        añadirEvento.addActionListener(e -> FormularioAñadirEvento());
        mostrarEventos.addActionListener(e -> MostrarEventos());
        
        // Mostrar el menú principal
        mostrarMenuPrincipal();
    }
    
    private JMenuItem crearItemMenu(String texto) {
        JMenuItem item = new JMenuItem(texto);
        item.setFont(fuenteNormal);
        return item;
    }
    
    private JButton crearBotonBonito(String texto, int ancho, int alto) {
        JButton boton = new JButton(texto);
        boton.setPreferredSize(new Dimension(ancho, alto));
        boton.setFont(fuenteNormal);
        boton.setBackground(new Color(70, 130, 180));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setOpaque(true);
        return boton;
    }
    
    private void mostrarMenuPrincipal() {
        contentPane.removeAll();
        
        JPanel panelCentral = new JPanel(new GridBagLayout());
        panelCentral.setBackground(colorFondo);
        panelCentral.setBorder(new EmptyBorder(50, 50, 50, 50));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel lblTitulo = new JLabel("GESTIÓN DE EVENTOS");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCentral.add(lblTitulo, gbc);
        
        // Botón Volver
        JButton btnVolver = crearBotonBonito("VOLVER", 180, 50);
        btnVolver.addActionListener(e -> {
            VistaMenuEventos eventos = new VistaMenuEventos();
            eventos.setVisible(true);
            dispose();
        });
        gbc.gridy = 1;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        panelCentral.add(btnVolver, gbc);
        
        // Añadir panel central al contentPane
        GridBagConstraints gbcMain = new GridBagConstraints();
        gbcMain.gridx = 0;
        gbcMain.gridy = 0;
        gbcMain.weightx = 1;
        gbcMain.weighty = 1;
        gbcMain.fill = GridBagConstraints.CENTER;
        contentPane.add(panelCentral, gbcMain);
        
        contentPane.revalidate();
        contentPane.repaint();
    }
    
    private void FormularioAñadirEvento() {
        JDialog dialog = new JDialog(this, "Añadir Evento", true);
        dialog.setSize(700, 500);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new GridBagLayout());
        
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBackground(colorFondo);
        panelFormulario.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel lblTitulo = new JLabel("FORMULARIO DE EVENTO");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelFormulario.add(lblTitulo, gbc);
        
        gbc.gridwidth = 1;
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setFont(fuenteNormal);
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelFormulario.add(lblNombre, gbc);
        
        JTextField txtNombre = new JTextField(20);
        txtNombre.setFont(fuenteNormal);
        gbc.gridx = 1;
        panelFormulario.add(txtNombre, gbc);
        
        JLabel lblDescripcion = new JLabel("Descripción:");
        lblDescripcion.setFont(fuenteNormal);
        gbc.gridx = 0;
        gbc.gridy = 2;
        panelFormulario.add(lblDescripcion, gbc);
        
        JTextArea txtDescripcion = new JTextArea(5, 20);
        txtDescripcion.setFont(fuenteNormal);
        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);
        JScrollPane scrollDescripcion = new JScrollPane(txtDescripcion);
        gbc.gridx = 1;
        panelFormulario.add(scrollDescripcion, gbc);
        
        JLabel lblFechaInicio = new JLabel("Fecha Inicio (YYYY-MM-DD):");
        lblFechaInicio.setFont(fuenteNormal);
        gbc.gridx = 0;
        gbc.gridy = 3;
        panelFormulario.add(lblFechaInicio, gbc);
        
        JTextField txtFechaInicio = new JTextField(20);
        txtFechaInicio.setFont(fuenteNormal);
        gbc.gridx = 1;
        panelFormulario.add(txtFechaInicio, gbc);
        
        JLabel lblFechaFin = new JLabel("Fecha Fin (YYYY-MM-DD):");
        lblFechaFin.setFont(fuenteNormal);
        gbc.gridx = 0;
        gbc.gridy = 4;
        panelFormulario.add(lblFechaFin, gbc);
        
        JTextField txtFechaFin = new JTextField(20);
        txtFechaFin.setFont(fuenteNormal);
        gbc.gridx = 1;
        panelFormulario.add(txtFechaFin, gbc);
        
        JLabel lblUbicacion = new JLabel("Ubicación:");
        lblUbicacion.setFont(fuenteNormal);
        gbc.gridx = 0;
        gbc.gridy = 5;
        panelFormulario.add(lblUbicacion, gbc);
        
        JTextField txtUbicacion = new JTextField(20);
        txtUbicacion.setFont(fuenteNormal);
        gbc.gridx = 1;
        panelFormulario.add(txtUbicacion, gbc);
        
        JButton btnGuardar = crearBotonBonito("GUARDAR", 150, 40);
        btnGuardar.addActionListener(e -> {
            try {
                guardarEvento(
                    txtNombre.getText(),
                    txtDescripcion.getText(),
                    txtFechaInicio.getText(),
                    txtFechaFin.getText(),
                    txtUbicacion.getText()
                );
                JOptionPane.showMessageDialog(dialog, "Evento añadido con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Error", JOptionPane.WARNING_MESSAGE);
            } catch (RuntimeException ex) {
                JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 6;
        panelFormulario.add(btnGuardar, gbc);
        
        JButton btnCancelar = crearBotonBonito("CANCELAR", 150, 40);
        btnCancelar.addActionListener(e -> dialog.dispose());
        gbc.gridx = 1;
        panelFormulario.add(btnCancelar, gbc);
        
        dialog.add(panelFormulario);
        dialog.setVisible(true);
    }
    
    private void MostrarEventos() {
        JDialog dialog = new JDialog(this, "Lista de Eventos", true);
        dialog.setSize(800, 600);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new GridBagLayout());
        
        JPanel panelLista = new JPanel(new GridBagLayout());
        panelLista.setBackground(colorFondo);
        panelLista.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.BOTH;
        
        JLabel lblTitulo = new JLabel("LISTA DE EVENTOS");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelLista.add(lblTitulo, gbc);
        
        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> listaEventos = new JList<>(model);
        listaEventos.setFont(fuenteNormal);
        listaEventos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(listaEventos);
        gbc.gridy = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;
        panelLista.add(scrollPane, gbc);
        
        JButton btnEliminar = crearBotonBonito("ELIMINAR", 150, 40);
        btnEliminar.setEnabled(false);
        listaEventos.addListSelectionListener(e -> {
            btnEliminar.setEnabled(!listaEventos.isSelectionEmpty());
        });
        gbc.gridy = 2;
        gbc.weighty = 0;
        panelLista.add(btnEliminar, gbc);
        
        // Cargar eventos desde la base de datos
        cargarEventos(model);
        
        btnEliminar.addActionListener(e -> {
            String eventoSeleccionado = listaEventos.getSelectedValue();
            if (eventoSeleccionado != null) {
                int confirmacion = JOptionPane.showConfirmDialog(dialog, 
                    "¿Está seguro de eliminar este evento?", "Confirmar eliminación", 
                    JOptionPane.YES_NO_OPTION);
                
                if (confirmacion == JOptionPane.YES_OPTION) {
                    int idEvento = Integer.parseInt(eventoSeleccionado.split(": ")[1].split("\n")[0]);
                    eliminarEvento(idEvento, model, eventoSeleccionado, dialog);
                }
            }
        });
        
        dialog.add(panelLista);
        dialog.setVisible(true);
    }
    
    private void cargarEventos(DefaultListModel<String> model) {
        String sql = "SELECT id_evento, nombre, descripcion, fecha_inicio, fecha_fin, ubicacion FROM eventos";
        
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                int id = rs.getInt("id_evento");
                String nombre = rs.getString("nombre");
                String descripcion = rs.getString("descripcion");
                String fechaInicio = rs.getString("fecha_inicio");
                String fechaFin = rs.getString("fecha_fin");
                String ubicacion = rs.getString("ubicacion");
                
                String evento = String.format(
                    "ID: %d | Nombre: %s | Fecha: %s a %s | Ubicación: %s",
                    id, nombre, fechaInicio, fechaFin, ubicacion
                );
                model.addElement(evento);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar eventos: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void eliminarEvento(int idEvento, DefaultListModel<String> model, String evento, JDialog dialog) {
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement("DELETE FROM eventos WHERE id_evento = ?")) {
            
            ps.setInt(1, idEvento);
            int rowsDeleted = ps.executeUpdate();
            
            if (rowsDeleted > 0) {
                model.removeElement(evento);
                JOptionPane.showMessageDialog(dialog, "Evento eliminado correctamente.", 
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(dialog, "Error al eliminar evento: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void guardarEvento(String nombre, String descripcion, String fechaInicio, String fechaFin, String ubicacion) {
        if (nombre == null || nombre.isEmpty() || 
            descripcion == null || descripcion.isEmpty() || 
            fechaInicio == null || fechaInicio.isEmpty() || 
            fechaFin == null || fechaFin.isEmpty() || 
            ubicacion == null || ubicacion.isEmpty()) {
            throw new IllegalArgumentException("Todos los campos deben estar completos.");
        }

        String sql = "INSERT INTO eventos (nombre, descripcion, fecha_inicio, fecha_fin, ubicacion) VALUES (?, ?, ?, ?, ?)";
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {
            
            ps.setString(1, nombre);
            ps.setString(2, descripcion);
            ps.setString(3, fechaInicio);
            ps.setString(4, fechaFin);
            ps.setString(5, ubicacion);

            ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new RuntimeException("Error al guardar el evento: " + ex.getMessage());
        }
    }
}