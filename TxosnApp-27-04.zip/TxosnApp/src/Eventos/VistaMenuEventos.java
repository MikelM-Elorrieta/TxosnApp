package Eventos;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Menu.VistaMenu;

import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

public class VistaMenuEventos extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private Color colorFondo = new Color(240, 240, 240); // Color de fondo claro
    private Font fuenteTitulos = new Font("Arial", Font.BOLD, 24);

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    VistaMenuEventos frame = new VistaMenuEventos();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public VistaMenuEventos() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame
        
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new GridBagLayout());
        
        mostrarMenuPrincipal();
    }
    
    private JButton crearBotonBonito(String texto, int ancho, int alto) {
        JButton boton = new JButton(texto);
        boton.setPreferredSize(new Dimension(ancho, alto));
        boton.setFont(new Font("Arial", Font.BOLD, 16));
        boton.setBackground(new Color(70, 130, 180)); // Color azul acero
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setOpaque(true);
        return boton;
    }
    
    private void mostrarMenuPrincipal() {
        contentPane.removeAll();
        
        JPanel panelCentral = new JPanel(new GridBagLayout());
        panelCentral.setBackground(colorFondo);
        panelCentral.setBorder(new EmptyBorder(50, 50, 50, 50));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel lblTitulo = new JLabel("MENÚ DE EVENTOS");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCentral.add(lblTitulo, gbc);
        
        gbc.gridwidth = 1;
        JButton btnAñadirEvento = crearBotonBonito("AÑADIR EVENTO", 180, 50);
        btnAñadirEvento.addActionListener(e -> {
            VistaAñadirEvento eventos = new VistaAñadirEvento();
            eventos.setVisible(true);
            dispose();
        });
        gbc.gridy = 1;
        gbc.gridx = 0;
        panelCentral.add(btnAñadirEvento, gbc);
        
        JButton btnMapa = crearBotonBonito("MAPA", 180, 50);
        btnMapa.addActionListener(e -> {
            // Aquí iría la lógica para mostrar el mapa
        });
        gbc.gridx = 1;
        panelCentral.add(btnMapa, gbc);
        
        // Botón Volver (si es necesario)
        JButton btnVolver = crearBotonBonito("VOLVER", 180, 50);
        btnVolver.addActionListener(e -> {
            VistaMenu menu = new VistaMenu();
            menu.setVisible(true);
            dispose();
        });
        gbc.gridy = 2;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        panelCentral.add(btnVolver, gbc);
        
        // Añadir panel central al contentPane
        GridBagConstraints gbcMain = new GridBagConstraints();
        gbcMain.gridx = 0;
        gbcMain.gridy = 0;
        gbcMain.weightx = 1;
        gbcMain.weighty = 1;
        gbcMain.fill = GridBagConstraints.CENTER;
        contentPane.add(panelCentral, gbcMain);
        
        contentPane.revalidate();
        contentPane.repaint();
    }
}