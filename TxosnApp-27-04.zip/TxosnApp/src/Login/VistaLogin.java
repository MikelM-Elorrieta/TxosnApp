package Login;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import Menu.VistaMenu;
import SQL.Conexion;

public class VistaLogin extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtUsuario;
    private JPasswordField txtContraseña;
    private Color colorFondo = new Color(240, 240, 240);
    private Color colorBotones = new Color(52, 152, 219);
    private Color colorTextoBotones = Color.WHITE;
    private Color colorCampos = new Color(255, 255, 255);
    private Color colorBordeCampos = new Color(206, 212, 218);
    private Font fuenteTitulos = new Font("Segoe UI", Font.BOLD, 24);
    private Font fuenteTexto = new Font("Segoe UI", Font.PLAIN, 14);
    private Font fuenteEtiquetas = new Font("Segoe UI", Font.BOLD, 16);

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                VistaLogin frame = new VistaLogin();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public VistaLogin() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("Sistema de Gestión - Inicio de Sesión");
        
        contentPane = new JPanel();
        contentPane.setBackground(colorFondo);
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);
        contentPane.setLayout(new GridBagLayout());
        
        // Panel central para el formulario
        JPanel panelLogin = new JPanel(new GridBagLayout());
        panelLogin.setBackground(colorFondo);
        panelLogin.setBorder(new EmptyBorder(40, 60, 40, 60));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.anchor = GridBagConstraints.CENTER;
        
        // Logo
        JLabel lblImagen = new JLabel();
        ImageIcon icono = new ImageIcon("src/resources/escudo.png");
        Image imagenRedimensionada = icono.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        lblImagen.setIcon(new ImageIcon(imagenRedimensionada));
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelLogin.add(lblImagen, gbc);
        
        // Título
        JLabel lblTitulo = new JLabel("INICIO DE SESIÓN");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setForeground(new Color(44, 62, 80));
        gbc.gridy = 1;
        panelLogin.add(lblTitulo, gbc);
        
        // Campo Usuario
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.EAST;
        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(fuenteEtiquetas);
        lblUsuario.setForeground(new Color(44, 62, 80));
        panelLogin.add(lblUsuario, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        txtUsuario = crearCampoTexto();
        txtUsuario.setPreferredSize(new Dimension(250, 35));
        panelLogin.add(txtUsuario, gbc);
        
        // Campo Contraseña
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.EAST;
        JLabel lblContraseña = new JLabel("Contraseña:");
        lblContraseña.setFont(fuenteEtiquetas);
        lblContraseña.setForeground(new Color(44, 62, 80));
        panelLogin.add(lblContraseña, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        txtContraseña = new JPasswordField();
        txtContraseña.setFont(fuenteTexto);
        txtContraseña.setBackground(colorCampos);
        txtContraseña.setBorder(new CompoundBorder(
            new LineBorder(colorBordeCampos, 1),
            new EmptyBorder(5, 10, 5, 10)
        ));
        txtContraseña.setPreferredSize(new Dimension(250, 35));
        panelLogin.add(txtContraseña, gbc);
        
        // Botón Login
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton btnLogin = crearBotonBonito("INICIAR SESIÓN", 200, 45);
        panelLogin.add(btnLogin, gbc);
        
        // Añadir panel al centro
        GridBagConstraints gbcMain = new GridBagConstraints();
        gbcMain.gridx = 0;
        gbcMain.gridy = 0;
        gbcMain.weightx = 1;
        gbcMain.weighty = 1;
        gbcMain.fill = GridBagConstraints.CENTER;
        contentPane.add(panelLogin, gbcMain);
        
        // Acción del botón Login
        btnLogin.addActionListener(e -> {
            String usuario = txtUsuario.getText();
            String contraseña = new String(txtContraseña.getPassword());

            if (autenticarUsuario(usuario, contraseña)) {
                VistaMenu vistaMenu = new VistaMenu();
                vistaMenu.setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Usuario o contraseña incorrectos", 
                    "Error de autenticación", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }
    
    private JButton crearBotonBonito(String texto, int ancho, int alto) {
        JButton boton = new JButton(texto);
        boton.setFont(fuenteEtiquetas);
        boton.setBackground(colorBotones);
        boton.setForeground(colorTextoBotones);
        boton.setFocusPainted(false);
        boton.setBorder(new CompoundBorder(
            new LineBorder(new Color(41, 128, 185), 1),
            new EmptyBorder(5, 15, 5, 15)
        ));
        boton.setPreferredSize(new Dimension(ancho, alto));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Efecto hover
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(MouseEvent e) {
                boton.setBackground(colorBotones);
            }
        });
        
        return boton;
    }
    
    private JTextField crearCampoTexto() {
        JTextField campo = new JTextField();
        campo.setFont(fuenteTexto);
        campo.setBackground(colorCampos);
        campo.setBorder(new CompoundBorder(
            new LineBorder(colorBordeCampos, 1),
            new EmptyBorder(5, 10, 5, 10)
        ));
        return campo;
    }
    
    private boolean autenticarUsuario(String usuario, String contraseña) {
        String sql = "SELECT * FROM usuario WHERE nombre_usuario = ? AND contraseña = ?";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, usuario);
            ps.setString(2, contraseña);
            ResultSet rs = ps.executeQuery();

            return rs.next(); // Si hay resultados, el usuario es válido.

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Error al conectar con la base de datos: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}