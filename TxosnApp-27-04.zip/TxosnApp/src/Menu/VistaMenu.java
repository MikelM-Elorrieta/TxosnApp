package Menu;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import Comisarios.VistaComisarios;
import Eventos.VistaMenuEventos;
import Inventario.VistaInventario;

public class VistaMenu extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private Color colorFondo = new Color(240, 240, 240);
    private Color colorBotones = new Color(52, 152, 219);
    private Color colorTextoBotones = Color.WHITE;
    private Font fuenteTitulos = new Font("Segoe UI", Font.BOLD, 28);
    private Font fuenteBotones = new Font("Segoe UI", Font.BOLD, 16);
    private Font fuenteTexto = new Font("Segoe UI", Font.PLAIN, 14);

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                VistaMenu frame = new VistaMenu();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public VistaMenu() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("Sistema de Gestión Principal");
        
        contentPane = new JPanel();
        contentPane.setBackground(colorFondo);
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);
        contentPane.setLayout(new GridBagLayout());
        
        // Panel central para el menú
        JPanel panelMenu = new JPanel(new GridBagLayout());
        panelMenu.setBackground(colorFondo);
        panelMenu.setBorder(new EmptyBorder(40, 60, 40, 60));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.anchor = GridBagConstraints.CENTER;
        
        // Logo - Añadido en la misma posición que en VistaLogin
        JLabel lblImagen = new JLabel();
        ImageIcon icono = new ImageIcon("src/resources/escudo.png");
        Image imagenRedimensionada = icono.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        lblImagen.setIcon(new ImageIcon(imagenRedimensionada));
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelMenu.add(lblImagen, gbc);
        
        // Título (ahora en posición 1)
        JLabel lblTitulo = new JLabel("MENÚ PRINCIPAL");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setForeground(new Color(44, 62, 80));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 1;
        panelMenu.add(lblTitulo, gbc);
        
        // Botón Comisarios (posición 2)
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.gridx = 0;
        JButton btnComisarios = crearBotonBonito("COMISARIOS", 200, 60);
        btnComisarios.addActionListener(e -> {
            VistaComisarios vistaComisarios = new VistaComisarios();
            vistaComisarios.setVisible(true);
            dispose();
        });
        panelMenu.add(btnComisarios, gbc);
        
        // Botón Inventario (posición 2)
        gbc.gridx = 1;
        JButton btnInventario = crearBotonBonito("INVENTARIO", 200, 60);
        btnInventario.addActionListener(e -> {
            VistaInventario vistaInventario = new VistaInventario();
            vistaInventario.setVisible(true);
            dispose();
        });
        panelMenu.add(btnInventario, gbc);
        
        // Botón Eventos (posición 3)
        gbc.gridx = 0;
        gbc.gridy = 3;
        JButton btnEventos = crearBotonBonito("EVENTOS", 200, 60);
        btnEventos.addActionListener(e -> {
            VistaMenuEventos vistaEventos = new VistaMenuEventos();
            vistaEventos.setVisible(true);
            dispose();
        });
        panelMenu.add(btnEventos, gbc);
        
        // Nuevo Botón Informes (posición 4)
        gbc.gridx = 1;
        gbc.gridy = 3;
        JButton btnInformes = crearBotonBonito("INFORMES", 200, 60);
        btnInformes.addActionListener(e -> {
            // Aquí puedes añadir la lógica para generar informes
            JOptionPane.showMessageDialog(this, 
                "Generando informe...", 
                "Informes", 
                JOptionPane.INFORMATION_MESSAGE);
        });
        panelMenu.add(btnInformes, gbc);
        
        // Añadir panel al centro
        GridBagConstraints gbcMain = new GridBagConstraints();
        gbcMain.gridx = 0;
        gbcMain.gridy = 0;
        gbcMain.weightx = 1;
        gbcMain.weighty = 1;
        gbcMain.fill = GridBagConstraints.CENTER;
        contentPane.add(panelMenu, gbcMain);
    }
    
    private JButton crearBotonBonito(String texto, int ancho, int alto) {
        JButton boton = new JButton(texto);
        boton.setFont(fuenteBotones);
        boton.setBackground(colorBotones);
        boton.setForeground(colorTextoBotones);
        boton.setFocusPainted(false);
        boton.setBorder(new CompoundBorder(
            new LineBorder(new Color(41, 128, 185), 1),
            new EmptyBorder(10, 20, 10, 20)
        ));
        boton.setPreferredSize(new Dimension(ancho, alto));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Efecto hover
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(MouseEvent e) {
                boton.setBackground(colorBotones);
            }
        });
        
        return boton;
    }
}
