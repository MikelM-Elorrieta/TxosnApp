package Comisarios;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.border.*;
import Menu.VistaMenu;
import SQL.Conexion;

public class VistaComisarios extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private Color colorFondo = new Color(240, 240, 240);
    private Color colorBotones = new Color(52, 152, 219);
    private Color colorTextoBotones = Color.WHITE;
    private Color colorCampos = new Color(255, 255, 255);
    private Color colorBordeCampos = new Color(206, 212, 218);
    private Font fuenteTitulos = new Font("Segoe UI", Font.BOLD, 18);
    private Font fuenteTexto = new Font("Segoe UI", Font.PLAIN, 14);
    private Font fuenteMenu = new Font("Segoe UI", Font.PLAIN, 14);

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                VistaComisarios frame = new VistaComisarios();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public VistaComisarios() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("Gestión de Comisarios");
        
        // Configurar la barra de menú
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(new Color(44, 62, 80));
        menuBar.setBorder(new EmptyBorder(5, 10, 5, 10));
        setJMenuBar(menuBar);

        // Crear los elementos del menú
        JMenuItem añadirComisario = crearItemMenu("AÑADIR COMISARIO");
        JMenuItem mostrarComisarios = crearItemMenu("MOSTRAR COMISARIOS");
        
        menuBar.add(añadirComisario);
        menuBar.add(mostrarComisarios);

        contentPane = new JPanel();
        contentPane.setBackground(colorFondo);
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);
        contentPane.setLayout(new GridBagLayout());

        // Botón Volver
        JButton btnVolver = crearBotonBonito("VOLVER", 150, 40);
        btnVolver.addActionListener(e -> {
            VistaMenu vistaMenu = new VistaMenu();
            vistaMenu.setVisible(true);
            dispose();
        });

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        contentPane.add(btnVolver, gbc);

        // Configurar acciones del menú
        añadirComisario.addActionListener(e -> mostrarFormularioAñadirUsuario());
        mostrarComisarios.addActionListener(e -> mostrarUsuarios());
    }

    private JMenuItem crearItemMenu(String texto) {
        JMenuItem item = new JMenuItem(texto);
        item.setFont(fuenteMenu);
        item.setForeground(Color.WHITE);
        item.setBackground(new Color(44, 62, 80));
        item.setBorder(new EmptyBorder(5, 10, 5, 10));
        return item;
    }

    private JButton crearBotonBonito(String texto, int ancho, int alto) {
        JButton boton = new JButton(texto);
        boton.setFont(fuenteTexto);
        boton.setBackground(colorBotones);
        boton.setForeground(colorTextoBotones);
        boton.setFocusPainted(false);
        boton.setBorder(new CompoundBorder(
            new LineBorder(new Color(41, 128, 185), 1),
            new EmptyBorder(5, 15, 5, 15)
        ));
        boton.setPreferredSize(new Dimension(ancho, alto));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(MouseEvent e) {
                boton.setBackground(colorBotones);
            }
        });
        
        return boton;
    }

    private JTextField crearCampoTexto() {
        JTextField campo = new JTextField();
        campo.setFont(fuenteTexto);
        campo.setBackground(colorCampos);
        campo.setBorder(new CompoundBorder(
            new LineBorder(colorBordeCampos, 1),
            new EmptyBorder(5, 10, 5, 10)
        ));
        campo.setPreferredSize(new Dimension(200, 30));
        return campo;
    }

    private void mostrarFormularioAñadirUsuario() {
        JDialog dialog = new JDialog(this, "Añadir Comisario", true);
        dialog.setLayout(new BorderLayout());
        dialog.setSize(500, 350);
        dialog.setLocationRelativeTo(this);
        
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBackground(colorFondo);
        panelFormulario.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL; // Añadido para que los campos se expandan
        
        // Título
        JLabel lblTitulo = new JLabel("NUEVO COMISARIO");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelFormulario.add(lblTitulo, gbc);
        
        // Campos del formulario
        gbc.gridwidth = 1;
        gbc.gridy++;
        
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setFont(fuenteTexto);
        gbc.gridx = 0;
        panelFormulario.add(lblNombre, gbc);
        
        gbc.gridx = 1;
        JTextField txtNombre = new JTextField(); // Campo de texto normal
        txtNombre.setFont(fuenteTexto);
        txtNombre.setPreferredSize(new Dimension(200, 30)); // Tamaño adecuado
        txtNombre.setEditable(true); // Asegurar que sea editable
        panelFormulario.add(txtNombre, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblApellido = new JLabel("Apellido:");
        lblApellido.setFont(fuenteTexto);
        panelFormulario.add(lblApellido, gbc);
        
        gbc.gridx = 1;
        JTextField txtApellido = new JTextField();
        txtApellido.setFont(fuenteTexto);
        txtApellido.setPreferredSize(new Dimension(200, 30));
        txtApellido.setEditable(true);
        panelFormulario.add(txtApellido, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setFont(fuenteTexto);
        panelFormulario.add(lblTelefono, gbc);
        
        gbc.gridx = 1;
        JTextField txtTelefono = new JTextField();
        txtTelefono.setFont(fuenteTexto);
        txtTelefono.setPreferredSize(new Dimension(200, 30));
        txtTelefono.setEditable(true);
        panelFormulario.add(txtTelefono, gbc);
        
        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setBackground(colorFondo);
        
        JButton btnGuardar = crearBotonBonito("GUARDAR", 120, 40);
        JButton btnCancelar = crearBotonBonito("CANCELAR", 120, 40);
        
        btnGuardar.addActionListener(e -> {
            try {
                String nombre = txtNombre.getText();
                String apellido = txtApellido.getText();
                int telefono = Integer.parseInt(txtTelefono.getText());
                
                if(guardarUsuario(nombre, apellido, telefono)) {
                    JOptionPane.showMessageDialog(dialog, 
                        "Comisario añadido correctamente", 
                        "Éxito", 
                        JOptionPane.INFORMATION_MESSAGE);
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, 
                        "Error al añadir el comisario", 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, 
                    "El teléfono debe ser un número válido", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        btnCancelar.addActionListener(e -> dialog.dispose());
        
        panelBotones.add(btnGuardar);
        panelBotones.add(btnCancelar);
        
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.CENTER;
        panelFormulario.add(panelBotones, gbc);
        
        dialog.add(panelFormulario, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    private void mostrarUsuarios() {
        String sql = "SELECT * FROM voluntarios";
        DefaultListModel<String> listModel = new DefaultListModel<>();
        List<Integer> idsUsuarios = new ArrayList<>();

        try (Connection conexion = Conexion.conectar();
             Statement stmt = conexion.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id_voluntario");
                String nombre = rs.getString("nombre");
                String apellido = rs.getString("apellido");
                int telefono = rs.getInt("telefono");

                listModel.addElement(nombre + " " + apellido + " - Tel: " + telefono);
                idsUsuarios.add(id);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            listModel.addElement("Error al obtener los comisarios");
        }

        JDialog dialog = new JDialog(this, "Lista de Comisarios", true);
        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(this);
        
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBackground(colorFondo);
        panelPrincipal.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        // Lista de comisarios
        JList<String> listaComisarios = new JList<>(listModel);
        listaComisarios.setFont(fuenteTexto);
        listaComisarios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(listaComisarios);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setBackground(colorFondo);
        
        JButton btnEliminar = crearBotonBonito("ELIMINAR", 120, 40);
        JButton btnCerrar = crearBotonBonito("CERRAR", 120, 40);
        
        btnEliminar.addActionListener(e -> {
            int selectedIndex = listaComisarios.getSelectedIndex();
            if (selectedIndex != -1) {
                int confirm = JOptionPane.showConfirmDialog(dialog, 
                    "¿Seguro que deseas eliminar este comisario?", 
                    "Confirmar Eliminación", 
                    JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    int idUsuario = idsUsuarios.get(selectedIndex);
                    if (eliminarUsuario(idUsuario)) {
                        listModel.remove(selectedIndex);
                        idsUsuarios.remove(selectedIndex);
                        JOptionPane.showMessageDialog(dialog, 
                            "Comisario eliminado correctamente", 
                            "Éxito", 
                            JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(dialog, 
                            "Error al eliminar el comisario", 
                            "Error", 
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(dialog, 
                    "Selecciona un comisario para eliminar", 
                    "Advertencia", 
                    JOptionPane.WARNING_MESSAGE);
            }
        });
        
        btnCerrar.addActionListener(e -> dialog.dispose());
        
        panelBotones.add(btnEliminar);
        panelBotones.add(btnCerrar);
        
        panelPrincipal.add(scrollPane, BorderLayout.CENTER);
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);
        
        dialog.add(panelPrincipal);
        dialog.setVisible(true);
    }

    private boolean guardarUsuario(String nombre, String apellido, int telefono) {
        String sql = "INSERT INTO voluntarios (nombre, apellido, telefono) VALUES (?, ?, ?)";
        Comisario comisario = new Comisario(nombre, apellido, telefono);

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, comisario.getNombre());
            ps.setString(2, comisario.getApellido());
            ps.setInt(3, comisario.getTelefono());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    private boolean eliminarUsuario(int id) {
        String sql = "DELETE FROM voluntarios WHERE id_voluntario = ?";
        
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}