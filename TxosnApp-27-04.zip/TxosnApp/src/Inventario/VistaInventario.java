package Inventario;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import Menu.VistaMenu;

public class VistaInventario extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private Color colorFondo = new Color(240, 240, 240);
    private Color colorBotones = new Color(52, 152, 219);
    private Color colorTextoBotones = Color.WHITE;
    private Font fuenteTitulos = new Font("Segoe UI", Font.BOLD, 24);
    private Font fuenteBotones = new Font("Segoe UI", Font.BOLD, 16);
    private Font fuenteTexto = new Font("Segoe UI", Font.PLAIN, 14);

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                VistaInventario frame = new VistaInventario();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public VistaInventario() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("Sistema de Gestión de Inventario");
        
        contentPane = new JPanel();
        contentPane.setBackground(colorFondo);
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);
        contentPane.setLayout(new GridBagLayout());
        
        // Panel central para los botones
        JPanel panelCentral = new JPanel(new GridBagLayout());
        panelCentral.setBackground(colorFondo);
        panelCentral.setBorder(new EmptyBorder(40, 60, 40, 60));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Título
        JLabel lblTitulo = new JLabel("GESTIÓN DE INVENTARIO");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setForeground(new Color(44, 62, 80));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCentral.add(lblTitulo, gbc);
        
        // Botones
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        
        JButton btnAlcohol = crearBotonBonito("BEBIDAS ALCOHÓLICAS", 250, 50);
        btnAlcohol.addActionListener(e -> {
            VistaAlcoholes alcoholes = new VistaAlcoholes();
            alcoholes.setVisible(true);
            dispose();
        });
        panelCentral.add(btnAlcohol, gbc);
        
        gbc.gridy = 2;
        JButton btnRefrescos = crearBotonBonito("REFRESCOS", 250, 50);
        btnRefrescos.addActionListener(e -> {
            VistaRefrescos refrescos = new VistaRefrescos();
            refrescos.setVisible(true);
            dispose();
        });
        panelCentral.add(btnRefrescos, gbc);
        
        gbc.gridy = 3;
        JButton btnPrendas = crearBotonBonito("PRENDAS", 250, 50);
        btnPrendas.addActionListener(e -> {
            VistaPrendas prendas = new VistaPrendas();
            prendas.setVisible(true);
            dispose();
        });
        panelCentral.add(btnPrendas, gbc);
        
        gbc.gridy = 4;
        JButton btnMaterial = crearBotonBonito("MATERIAL", 250, 50);
        btnMaterial.addActionListener(e -> {
            // VistaMaterial material = new VistaMaterial();
            // material.setVisible(true);
            // dispose();
            JOptionPane.showMessageDialog(this, 
                "Funcionalidad en desarrollo", 
                "Información", 
                JOptionPane.INFORMATION_MESSAGE);
        });
        panelCentral.add(btnMaterial, gbc);
        
        gbc.gridy = 5;
        JButton btnComida = crearBotonBonito("ALIMENTICIO", 250, 50);
        btnComida.addActionListener(e -> {
            VistaComida comida = new VistaComida();
            comida.setVisible(true);
            dispose();
        });
        panelCentral.add(btnComida, gbc);
        
        // Botón Volver
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        JButton btnVolver = crearBotonBonito("VOLVER AL MENÚ", 200, 45);
        btnVolver.addActionListener(e -> {
            VistaMenu menu = new VistaMenu();
            menu.setVisible(true);
            dispose();
        });
        panelCentral.add(btnVolver, gbc);
        
        // Añadir panel al centro
        GridBagConstraints gbcMain = new GridBagConstraints();
        gbcMain.gridx = 0;
        gbcMain.gridy = 0;
        gbcMain.weightx = 1;
        gbcMain.weighty = 1;
        gbcMain.fill = GridBagConstraints.CENTER;
        contentPane.add(panelCentral, gbcMain);
    }
    
    private JButton crearBotonBonito(String texto, int ancho, int alto) {
        JButton boton = new JButton(texto);
        boton.setFont(fuenteBotones);
        boton.setBackground(colorBotones);
        boton.setForeground(colorTextoBotones);
        boton.setFocusPainted(false);
        boton.setBorder(new CompoundBorder(
            new LineBorder(new Color(41, 128, 185), 1),
            new EmptyBorder(10, 15, 10, 15)
        ));
        boton.setPreferredSize(new Dimension(ancho, alto));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Efecto hover
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(MouseEvent e) {
                boton.setBackground(colorBotones);
            }
        });
        
        return boton;
    }
}