package Inventario;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import Menu.VistaMenu;
import SQL.Conexion;

public class VistaAlcoholes extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private Color colorFondo = new Color(240, 240, 240);
    private Color colorBotones = new Color(52, 152, 219);
    private Color colorTextoBotones = Color.WHITE;
    private Color colorCampos = new Color(255, 255, 255);
    private Color colorBordeCampos = new Color(206, 212, 218);
    private Font fuenteTitulos = new Font("Segoe UI", Font.BOLD, 18);
    private Font fuenteTexto = new Font("Segoe UI", Font.PLAIN, 14);
    private Font fuenteMenu = new Font("Segoe UI", Font.PLAIN, 14);

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                VistaAlcoholes frame = new VistaAlcoholes();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public VistaAlcoholes() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("Gestión de Bebidas Alcohólicas");
        
        // Configurar la barra de menú
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(new Color(44, 62, 80));
        menuBar.setBorder(new EmptyBorder(5, 10, 5, 10));
        setJMenuBar(menuBar);

        // Crear los elementos del menú
        JMenuItem añadirAlcohol = crearItemMenu("AÑADIR ALCOHOL");
        JMenuItem mostrarAlcoholes = crearItemMenu("MOSTRAR ALCOHOLES");
        
        menuBar.add(añadirAlcohol);
        menuBar.add(mostrarAlcoholes);

        contentPane = new JPanel();
        contentPane.setBackground(colorFondo);
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);
        contentPane.setLayout(new GridBagLayout());

        // Botón Volver
        JButton btnVolver = crearBotonBonito("VOLVER", 150, 40);
        btnVolver.addActionListener(e -> {
            VistaInventario vistaInventario = new VistaInventario();
            vistaInventario.setVisible(true);
            dispose();
        });

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        contentPane.add(btnVolver, gbc);

        // Configurar acciones del menú
        añadirAlcohol.addActionListener(e -> mostrarFormularioAlcohol());
        mostrarAlcoholes.addActionListener(e -> mostrarListaAlcoholes());
    }

    private JMenuItem crearItemMenu(String texto) {
        JMenuItem item = new JMenuItem(texto);
        item.setFont(fuenteMenu);
        item.setForeground(Color.WHITE);
        item.setBackground(new Color(44, 62, 80));
        item.setBorder(new EmptyBorder(5, 10, 5, 10));
        return item;
    }

    private JButton crearBotonBonito(String texto, int ancho, int alto) {
        JButton boton = new JButton(texto);
        boton.setFont(fuenteTexto);
        boton.setBackground(colorBotones);
        boton.setForeground(colorTextoBotones);
        boton.setFocusPainted(false);
        boton.setBorder(new CompoundBorder(
            new LineBorder(new Color(41, 128, 185), 1),
            new EmptyBorder(5, 15, 5, 15)
        ));
        boton.setPreferredSize(new Dimension(ancho, alto));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(MouseEvent e) {
                boton.setBackground(colorBotones);
            }
        });
        
        return boton;
    }

    private JTextField crearCampoTexto() {
        JTextField campo = new JTextField();
        campo.setFont(fuenteTexto);
        campo.setBackground(colorCampos);
        campo.setBorder(new CompoundBorder(
            new LineBorder(colorBordeCampos, 1),
            new EmptyBorder(5, 10, 5, 10)
        ));
        campo.setPreferredSize(new Dimension(200, 30));
        return campo;
    }

    private void mostrarFormularioAlcohol() {
        contentPane.removeAll();
        
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBackground(colorFondo);
        panelFormulario.setBorder(new EmptyBorder(30, 50, 30, 50));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Título
        JLabel lblTitulo = new JLabel("AÑADIR BEBIDA ALCOHÓLICA");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelFormulario.add(lblTitulo, gbc);
        
        // Campos del formulario
        gbc.gridwidth = 1;
        gbc.gridy++;
        
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setFont(fuenteTexto);
        gbc.gridx = 0;
        panelFormulario.add(lblNombre, gbc);
        
        gbc.gridx = 1;
        JTextField txtNombre = crearCampoTexto();
        panelFormulario.add(txtNombre, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblCantidad = new JLabel("Cantidad (ml):");
        lblCantidad.setFont(fuenteTexto);
        panelFormulario.add(lblCantidad, gbc);
        
        gbc.gridx = 1;
        JTextField txtCantidad = crearCampoTexto();
        panelFormulario.add(txtCantidad, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblPrecio = new JLabel("Precio (€):");
        lblPrecio.setFont(fuenteTexto);
        panelFormulario.add(lblPrecio, gbc);
        
        gbc.gridx = 1;
        JTextField txtPrecio = crearCampoTexto();
        panelFormulario.add(txtPrecio, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblPrecioCompra = new JLabel("Precio de compra (€):");
        lblPrecioCompra.setFont(fuenteTexto);
        panelFormulario.add(lblPrecioCompra, gbc);
        
        gbc.gridx = 1;
        JTextField txtPrecioCompra = crearCampoTexto();
        panelFormulario.add(txtPrecioCompra, gbc);
        
       
        
        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setBackground(colorFondo);
        
        JButton btnGuardar = crearBotonBonito("GUARDAR", 120, 40);
        JButton btnCancelar = crearBotonBonito("CANCELAR", 120, 40);
        
        btnGuardar.addActionListener(e -> {
            try {
                String nombre = txtNombre.getText();
                int cantidad = Integer.parseInt(txtCantidad.getText());
                double precio = Double.parseDouble(txtPrecio.getText());
                double precioCompra = Double.parseDouble(txtPrecioCompra.getText());
                
                if(guardarAlcohol(nombre, cantidad, precio, precioCompra)) {
                    JOptionPane.showMessageDialog(this, 
                        "Bebida añadida correctamente", 
                        "Éxito", 
                        JOptionPane.INFORMATION_MESSAGE);
                    mostrarListaAlcoholes();
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Error al añadir la bebida", 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Cantidad y Precio deben ser números válidos", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        btnCancelar.addActionListener(e -> mostrarListaAlcoholes());
        
        panelBotones.add(btnGuardar);
        panelBotones.add(btnCancelar);
        
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.CENTER;
        panelFormulario.add(panelBotones, gbc);
        
        // Añadir panel al centro
        GridBagConstraints gbcMain = new GridBagConstraints();
        gbcMain.gridx = 0;
        gbcMain.gridy = 0;
        gbcMain.weightx = 1;
        gbcMain.weighty = 1;
        gbcMain.fill = GridBagConstraints.CENTER;
        contentPane.add(panelFormulario, gbcMain);
        
        contentPane.revalidate();
        contentPane.repaint();
    }

    private void mostrarListaAlcoholes() {
        contentPane.removeAll();
        
        JPanel panelLista = new JPanel(new BorderLayout());
        panelLista.setBackground(colorFondo);
        panelLista.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        // Título
        JLabel lblTitulo = new JLabel("LISTA DE BEBIDAS ALCOHÓLICAS");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        panelLista.add(lblTitulo, BorderLayout.NORTH);
        
        // Lista de bebidas
        DefaultListModel<String> listModel = new DefaultListModel<>();
        JList<String> listaBebidas = new JList<>(listModel);
        listaBebidas.setFont(fuenteTexto);
        listaBebidas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(listaBebidas);
        
        // Botones
        JButton btnEliminar = crearBotonBonito("ELIMINAR", 120, 40);
        btnEliminar.setEnabled(false);
        
        JButton btnVolver = crearBotonBonito("VOLVER", 120, 40);
        
        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setBackground(colorFondo);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnVolver);
        
        // Cargar datos de la base de datos
        String sql = "SELECT id_bebida, nombre, cantidad, precio_venta, precio_compra FROM bebidas WHERE tipo = 'alcohólica'";
        
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                int id = rs.getInt("id_bebida");
                String nombre = rs.getString("nombre");
                int cantidad = rs.getInt("cantidad");
                double precio = rs.getDouble("precio_venta");
                double precioCompra = rs.getDouble("precio_compra");
                
                String item = String.format("ID: %d | %s | %d ml | %.2f€", id, nombre, cantidad, precio, precioCompra);
                listModel.addElement(item);
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Error al cargar las bebidas: " + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
        
        // Habilitar botón eliminar cuando hay selección
        listaBebidas.addListSelectionListener(e -> {
            btnEliminar.setEnabled(!listaBebidas.isSelectionEmpty());
        });
        
        // Acción para eliminar
        btnEliminar.addActionListener(e -> {
            String seleccion = listaBebidas.getSelectedValue();
            if (seleccion != null) {
                int id = Integer.parseInt(seleccion.split("\\|")[0].replace("ID:", "").trim());
                
                int confirm = JOptionPane.showConfirmDialog(this, 
                    "¿Eliminar esta bebida?", 
                    "Confirmar", 
                    JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    if (eliminarAlcohol(id)) {
                        listModel.remove(listaBebidas.getSelectedIndex());
                        JOptionPane.showMessageDialog(this, 
                            "Bebida eliminada correctamente", 
                            "Éxito", 
                            JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(this, 
                            "Error al eliminar la bebida", 
                            "Error", 
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        
        // Acción para volver
        btnVolver.addActionListener(e -> {
            VistaInventario vistaInventario = new VistaInventario();
            vistaInventario.setVisible(true);
            dispose();
        });
        
        panelLista.add(scrollPane, BorderLayout.CENTER);
        panelLista.add(panelBotones, BorderLayout.SOUTH);
        
        contentPane.add(panelLista, new GridBagConstraints());
        contentPane.revalidate();
        contentPane.repaint();
    }

    private boolean guardarAlcohol(String nombre, int cantidad, double precio, double precioCompra) {
        String sql = "INSERT INTO bebidas (nombre, tipo, cantidad, precio_venta, precio_compra) VALUES (?, 'alcohólica', ?, ?)";
        
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {
            
            ps.setString(1, nombre);
            ps.setInt(2, cantidad);
            ps.setDouble(3, precio);
            ps.setDouble(4, precioCompra);
            
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    private boolean eliminarAlcohol(int id) {
        String sql = "DELETE FROM bebidas WHERE id_bebida = ?";
        
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
