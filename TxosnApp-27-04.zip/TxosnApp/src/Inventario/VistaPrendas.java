package Inventario;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;

import SQL.Conexion;

public class VistaPrendas extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private Color colorFondo = new Color(240, 240, 240);
    private Color colorBotones = new Color(52, 152, 219);
    private Color colorTextoBotones = Color.WHITE;
    private Font fuenteTitulos = new Font("Segoe UI", Font.BOLD, 18);
    private Font fuenteTexto = new Font("Segoe UI", Font.PLAIN, 14);
    private Color colorCampos = new Color(255, 255, 255);
    private Color colorBordeCampos = new Color(206, 212, 218);

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                VistaPrendas frame = new VistaPrendas();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public VistaPrendas() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("Sistema de Gestión de Inventario - Prendas");
        
        // Configurar la barra de menú
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(new Color(44, 62, 80));
        menuBar.setBorder(new EmptyBorder(5, 10, 5, 10));
        setJMenuBar(menuBar);

        // Crear los elementos del menú
        JMenuItem añadirPrenda = crearItemMenu("AÑADIR PRENDA");
        JMenuItem mostrarPrendas = crearItemMenu("MOSTRAR PRENDAS");

        menuBar.add(añadirPrenda);
        menuBar.add(Box.createHorizontalStrut(15));
        menuBar.add(mostrarPrendas);

        contentPane = new JPanel();
        contentPane.setBackground(colorFondo);
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);
        contentPane.setLayout(new GridBagLayout());
        
        

        // Configurar acciones
        añadirPrenda.addActionListener(e -> mostrarBotonesPrendas());
        mostrarPrendas.addActionListener(e -> mostrarListadoPrendas());

        // Botón Volver (inicialmente oculto)
        JButton btnVolver = crearBotonBonito("VOLVER", 150, 40);
        btnVolver.addActionListener(e -> {
            VistaInventario vistaInventario = new VistaInventario();
            vistaInventario.setVisible(true);
            dispose();
        });

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        contentPane.add(btnVolver, gbc);
    }

    private JMenuItem crearItemMenu(String texto) {
        JMenuItem item = new JMenuItem(texto);
        item.setFont(fuenteTexto);
        item.setForeground(Color.WHITE);
        item.setBackground(new Color(44, 62, 80));
        item.setBorder(new EmptyBorder(5, 10, 5, 10));
        return item;
    }

    private JButton crearBotonBonito(String texto, int ancho, int alto) {
        JButton boton = new JButton(texto);
        boton.setFont(fuenteTexto);
        boton.setBackground(colorBotones);
        boton.setForeground(colorTextoBotones);
        boton.setFocusPainted(false);
        boton.setBorder(new CompoundBorder(
            new LineBorder(new Color(41, 128, 185), 1),
            new EmptyBorder(5, 15, 5, 15)
        ));
        boton.setPreferredSize(new Dimension(ancho, alto));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Efecto hover
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(MouseEvent e) {
                boton.setBackground(colorBotones);
            }
        });
        
        return boton;
    }

    private JTextField crearCampoTexto() {
        JTextField campo = new JTextField();
        campo.setFont(fuenteTexto);
        campo.setBackground(colorCampos);
        campo.setBorder(new CompoundBorder(
            new LineBorder(colorBordeCampos, 1),
            new EmptyBorder(5, 10, 5, 10)
        ));
        campo.setPreferredSize(new Dimension(200, 30));
        return campo;
    }

    private void mostrarBotonesPrendas() {
        contentPane.removeAll();
        
        JPanel panelCentral = new JPanel(new GridBagLayout());
        panelCentral.setBackground(colorFondo);
        panelCentral.setBorder(new EmptyBorder(50, 50, 50, 50));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel lblTitulo = new JLabel("SELECCIONE EL TIPO DE PRENDA");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCentral.add(lblTitulo, gbc);
        
        gbc.gridwidth = 1;
        JButton btnCamisetas = crearBotonBonito("CAMISETAS", 180, 50);
        btnCamisetas.addActionListener(e -> mostrarFormularioCamiseta());
        gbc.gridy = 1;
        gbc.gridx = 0;
        panelCentral.add(btnCamisetas, gbc);
        
        JButton btnPolos = crearBotonBonito("POLOS", 180, 50);
        btnPolos.addActionListener(e -> mostrarFormularioPolo());
        gbc.gridx = 1;
        panelCentral.add(btnPolos, gbc);
        
        JButton btnPañuelos = crearBotonBonito("PAÑUELOS", 180, 50);
        btnPañuelos.addActionListener(e -> mostrarFormularioPañuelo());
        gbc.gridy = 2;
        gbc.gridx = 0;
        panelCentral.add(btnPañuelos, gbc);
        
        JButton btnToteBags = crearBotonBonito("TOTE BAGS", 180, 50);
        btnToteBags.addActionListener(e -> mostrarFormularioToteBag());
        gbc.gridx = 1;
        panelCentral.add(btnToteBags, gbc);
        
        // Botón Volver
        JButton btnVolver = crearBotonBonito("VOLVER", 180, 50);
        btnVolver.addActionListener(e -> {
        	VistaInventario vistaInventario = new VistaInventario();
            vistaInventario.setVisible(true);
            dispose();
        });
        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        panelCentral.add(btnVolver, gbc);
        
        // Añadir panel central al contentPane
        GridBagConstraints gbcMain = new GridBagConstraints();
        gbcMain.gridx = 0;
        gbcMain.gridy = 0;
        gbcMain.weightx = 1;
        gbcMain.weighty = 1;
        gbcMain.fill = GridBagConstraints.CENTER;
        contentPane.add(panelCentral, gbcMain);
        
        contentPane.revalidate();
        contentPane.repaint();
    }

    private void mostrarFormularioCamiseta() {
        mostrarFormularioConTalla("Camiseta");
    }

    private void mostrarFormularioPolo() {
        mostrarFormularioConTalla("Polo");
    }

    private void mostrarFormularioPañuelo() {
        mostrarFormularioSinTalla("Pañuelo");
    }

    private void mostrarFormularioToteBag() {
        mostrarFormularioSinTalla("Tote Bag");
    }

    private void mostrarFormularioConTalla(String tipoPrenda) {
        contentPane.removeAll();
        
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBackground(colorFondo);
        panelFormulario.setBorder(new EmptyBorder(30, 50, 30, 50));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Título
        JLabel lblTitulo = new JLabel("AÑADIR " + tipoPrenda.toUpperCase());
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelFormulario.add(lblTitulo, gbc);
        
        // Campos del formulario
        gbc.gridwidth = 1;
        gbc.gridy++;
        
        JLabel lblTalla = new JLabel("Talla:");
        lblTalla.setFont(fuenteTexto);
        gbc.gridx = 0;
        panelFormulario.add(lblTalla, gbc);
        
        JComboBox<String> comboBoxTalla = new JComboBox<>(new String[]{"S", "M", "L", "XL"});
        comboBoxTalla.setFont(fuenteTexto);
        comboBoxTalla.setBackground(colorCampos);
        comboBoxTalla.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(colorBordeCampos),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        gbc.gridx = 1;
        panelFormulario.add(comboBoxTalla, gbc);
        
        gbc.gridy++;
        gbc.gridx = 0;
        JLabel lblPrecio = new JLabel("Precio Venta:");
        lblPrecio.setFont(fuenteTexto);
        panelFormulario.add(lblPrecio, gbc);
        
        gbc.gridx = 1;
        JTextField txtPrecio = crearCampoTexto();
        panelFormulario.add(txtPrecio, gbc);
        
        gbc.gridy++;
        gbc.gridx = 0;
        JLabel lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setFont(fuenteTexto);
        panelFormulario.add(lblCantidad, gbc);
        
        gbc.gridx = 1;
        JTextField txtCantidad = crearCampoTexto();
        panelFormulario.add(txtCantidad, gbc);
        
        gbc.gridy++;
        gbc.gridx = 0;
        JLabel lblColor = new JLabel("Color:");
        lblColor.setFont(fuenteTexto);
        panelFormulario.add(lblColor, gbc);
        
        gbc.gridx = 1;
        JTextField txtColor = crearCampoTexto();
        panelFormulario.add(txtColor, gbc);
        
        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setBackground(colorFondo);
        
        JButton btnGuardar = crearBotonBonito("GUARDAR", 120, 40);
        JButton btnVolver = crearBotonBonito("VOLVER", 120, 40);
        
        btnVolver.addActionListener(e -> mostrarBotonesPrendas());
        btnGuardar.addActionListener(e -> {
            try {
                // Validar campos vacíos
                if(txtPrecio.getText().isEmpty() || txtCantidad.getText().isEmpty() || txtColor.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Validar números positivos
                double precio = Double.parseDouble(txtPrecio.getText());
                if(precio <= 0) {
                    JOptionPane.showMessageDialog(this, "El precio debe ser mayor que 0", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                int cantidad = Integer.parseInt(txtCantidad.getText());
                if(cantidad <= 0) {
                    JOptionPane.showMessageDialog(this, "La cantidad debe ser mayor que 0", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Obtener valores del formulario
                String talla = (String) comboBoxTalla.getSelectedItem();
                String color = txtColor.getText();
                
                // Insertar en la base de datos
                try (Connection conexion = SQL.Conexion.conectar()) {
                    if(conexion != null) {
                        String sql = "INSERT INTO merchandising (tipo, precio_venta, talla, cantidad, color) VALUES (?, ?, ?, ?, ?)";
                        
                        try (PreparedStatement pstmt = conexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                            pstmt.setString(1, tipoPrenda);
                            pstmt.setDouble(2, precio);
                            pstmt.setString(3, talla);
                            pstmt.setInt(4, cantidad);
                            pstmt.setString(5, color);
                            
                            int affectedRows = pstmt.executeUpdate();
                            
                            if(affectedRows > 0) {
                                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                                    if (generatedKeys.next()) {
                                        int idGenerado = generatedKeys.getInt(1);
                                        JOptionPane.showMessageDialog(this, 
                                            tipoPrenda + " guardada correctamente\nID: " + idGenerado, 
                                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                                        // Limpiar campos después de guardar
                                        comboBoxTalla.setSelectedIndex(0);
                                        txtPrecio.setText("");
                                        txtCantidad.setText("");
                                        txtColor.setText("");
                                    }
                                }
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Formato incorrecto en números: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error en la base de datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
        
        panelBotones.add(btnGuardar);
        panelBotones.add(btnVolver);
        
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.CENTER;
        panelFormulario.add(panelBotones, gbc);
        
        // Añadir panel al centro
        GridBagConstraints gbcMain = new GridBagConstraints();
        gbcMain.gridx = 0;
        gbcMain.gridy = 0;
        gbcMain.weightx = 1;
        gbcMain.weighty = 1;
        gbcMain.fill = GridBagConstraints.CENTER;
        contentPane.add(panelFormulario, gbcMain);
        
        contentPane.revalidate();
        contentPane.repaint();
    }

    private void mostrarFormularioSinTalla(String tipoPrenda) {
        contentPane.removeAll();
        
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBackground(colorFondo);
        panelFormulario.setBorder(new EmptyBorder(30, 50, 30, 50));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Título
        JLabel lblTitulo = new JLabel("AÑADIR " + tipoPrenda.toUpperCase());
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelFormulario.add(lblTitulo, gbc);
        
        // Campos del formulario
        gbc.gridwidth = 1;
        gbc.gridy++;
        
        JLabel lblPrecio = new JLabel("Precio Venta:");
        lblPrecio.setFont(fuenteTexto);
        gbc.gridx = 0;
        panelFormulario.add(lblPrecio, gbc);
        
        gbc.gridx = 1;
        JTextField txtPrecio = crearCampoTexto();
        panelFormulario.add(txtPrecio, gbc);
        
        gbc.gridy++;
        gbc.gridx = 0;
        JLabel lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setFont(fuenteTexto);
        panelFormulario.add(lblCantidad, gbc);
        
        gbc.gridx = 1;
        JTextField txtCantidad = crearCampoTexto();
        panelFormulario.add(txtCantidad, gbc);
        
        gbc.gridy++;
        gbc.gridx = 0;
        JLabel lblColor = new JLabel("Color:");
        lblColor.setFont(fuenteTexto);
        panelFormulario.add(lblColor, gbc);
        
        gbc.gridx = 1;
        JTextField txtColor = crearCampoTexto();
        panelFormulario.add(txtColor, gbc);
        
        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setBackground(colorFondo);
        
        JButton btnGuardar = crearBotonBonito("GUARDAR", 120, 40);
        JButton btnVolver = crearBotonBonito("VOLVER", 120, 40);
        
        btnVolver.addActionListener(e -> mostrarBotonesPrendas());
        btnGuardar.addActionListener(e -> {
            try {
                // Validar campos vacíos
                if(txtPrecio.getText().isEmpty() || txtCantidad.getText().isEmpty() || txtColor.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Obtener valores del formulario
                double precio = Double.parseDouble(txtPrecio.getText());
                int cantidad = Integer.parseInt(txtCantidad.getText());
                String color = txtColor.getText();
                
                // Insertar en la base de datos
                try (Connection conexion = SQL.Conexion.conectar()) {
                    if(conexion != null) {
                        String sql = "INSERT INTO merchandising (tipo, precio_venta, cantidad, color) VALUES (?, ?, ?, ?)";
                        
                        try (PreparedStatement pstmt = conexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                            pstmt.setString(1, tipoPrenda);
                            pstmt.setDouble(2, precio);
                            pstmt.setInt(3, cantidad);
                            pstmt.setString(4, color);
                            
                            int affectedRows = pstmt.executeUpdate();
                            
                            if(affectedRows > 0) {
                                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                                    if (generatedKeys.next()) {
                                        int idGenerado = generatedKeys.getInt(1);
                                        JOptionPane.showMessageDialog(this, 
                                            tipoPrenda + " guardada correctamente\nID: " + idGenerado, 
                                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                                        // Limpiar campos después de guardar
                                        txtPrecio.setText("");
                                        txtCantidad.setText("");
                                        txtColor.setText("");
                                    }
                                }
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Formato incorrecto en números: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error en la base de datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
        
        panelBotones.add(btnGuardar);
        panelBotones.add(btnVolver);
        
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.CENTER;
        panelFormulario.add(panelBotones, gbc);
        
        // Añadir panel al centro
        GridBagConstraints gbcMain = new GridBagConstraints();
        gbcMain.gridx = 0;
        gbcMain.gridy = 0;
        gbcMain.weightx = 1;
        gbcMain.weighty = 1;
        gbcMain.fill = GridBagConstraints.CENTER;
        contentPane.add(panelFormulario, gbcMain);
        
        contentPane.revalidate();
        contentPane.repaint();
    }

    private void mostrarListadoPrendas() {
        contentPane.removeAll();
        
        JPanel panelListado = new JPanel(new BorderLayout());
        panelListado.setBackground(colorFondo);
        panelListado.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        JLabel lblTitulo = new JLabel("LISTADO DE PRENDAS");
        lblTitulo.setFont(fuenteTitulos);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        panelListado.add(lblTitulo, BorderLayout.NORTH);
        
        // 1. Modelo de tabla
        String[] columnas = {"ID", "Nombre", "Tipo", "Talla", "Color", "Precio"};
        DefaultTableModel modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Tabla no editable
            }
        };
        
        // 2. Tabla con personalización
        JTable tablaPrendas = new JTable(modeloTabla);
        tablaPrendas.setFont(fuenteTexto);
        tablaPrendas.setRowHeight(30);
        tablaPrendas.getTableHeader().setFont(fuenteTexto.deriveFont(Font.BOLD));
        tablaPrendas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // 3. ScrollPane con borde mejorado
        JScrollPane scrollPane = new JScrollPane(tablaPrendas);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(15, 0, 15, 0),
            BorderFactory.createLineBorder(colorFondo.darker(), 1)
        ));
        
        // 4. Botones funcionales
        JButton btnEliminar = crearBotonBonito("ELIMINAR", 120, 40);
        btnEliminar.setEnabled(false);
        
        JButton btnVolver = crearBotonBonito("VOLVER", 120, 40);
        
        // 5. Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setBackground(colorFondo);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnVolver);
        
        // 6. Cargar datos desde BD
        String sql = "SELECT id_merch, tipo, precio_venta, talla, cantidad, color FROM merchandising";
        
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id_merch"),
                    rs.getString("tipo"),
                    rs.getDouble("precio_venta"),
                    rs.getString("talla"),
                    rs.getInt("cantidad"),
                    rs.getString("color")
                };
                modeloTabla.addRow(fila);
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Error al cargar prendas: " + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
        
        // 7. Habilitar botón eliminar con selección
        tablaPrendas.getSelectionModel().addListSelectionListener(e -> {
            btnEliminar.setEnabled(tablaPrendas.getSelectedRow() != -1);
        });
        
        // 8. Acción eliminar
        btnEliminar.addActionListener(e -> {
            int filaSeleccionada = tablaPrendas.getSelectedRow();
            if (filaSeleccionada != -1) {
                int idPrenda = (int) modeloTabla.getValueAt(filaSeleccionada, 0);
                
                int confirm = JOptionPane.showConfirmDialog(this, 
                    "¿Eliminar esta prenda?", 
                    "Confirmar", 
                    JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    if (eliminarPrenda(idPrenda)) {
                        modeloTabla.removeRow(filaSeleccionada);
                        JOptionPane.showMessageDialog(this, 
                            "Prenda eliminada correctamente", 
                            "Éxito", 
                            JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(this, 
                            "Error al eliminar la prenda", 
                            "Error", 
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        
        // 9. Acción volver (manteniendo tu implementación original)
        btnVolver.addActionListener(e -> mostrarBotonesPrendas());
        
        // 10. Ensamblado final
        panelListado.add(scrollPane, BorderLayout.CENTER);
        panelListado.add(panelBotones, BorderLayout.SOUTH);
        
        contentPane.add(panelListado, new GridBagConstraints());
        contentPane.revalidate();
        contentPane.repaint();
    }

    // Método auxiliar para eliminar prendas (debes implementar la lógica real)
    private boolean eliminarPrenda(int idPrenda) {
        String sql = "DELETE FROM merchandising WHERE id_merch = ?";
        
        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {
            
            ps.setInt(1, idPrenda);
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

}