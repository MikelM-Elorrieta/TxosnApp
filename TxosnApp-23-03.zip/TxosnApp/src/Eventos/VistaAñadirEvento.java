package Eventos;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import SQL.Conexion;

import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Toolkit;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class VistaAñadirEvento extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel contentPane_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaAñadirEvento frame = new VistaAñadirEvento();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaAñadirEvento() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		contentPane_1 = new JPanel();
		contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));

		// Crear los elementos del menú
		JMenuItem añadirEvento = new JMenuItem("AÑADIR EVENTO");
		JMenuItem mostrarEventos = new JMenuItem("MOSTRAR EVENTOS");

		menuBar.add(añadirEvento);
		menuBar.add(mostrarEventos);

		setContentPane(contentPane_1);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane_1.setLayout(gbl_contentPane);
		
		JButton btnVolver = new JButton("VOLVER");
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridx = 11;
		gbc_btnNewButton.gridy = 7;
		contentPane_1.add(btnVolver, gbc_btnNewButton);
		
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VistaMenuEventos eventos = new VistaMenuEventos();
				eventos.setVisible(true);
				dispose();
			}
		});
		
		añadirEvento.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				FormularioAñadirEvento();
				
			}
		});
		
		mostrarEventos.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				MostrarEventos();
				
			}
		});
	}
	
	private void FormularioAñadirEvento() {
		// Crear el JDialog para el formulario
	    JDialog dialog = new JDialog(this, "Añadir Evento", true);
	    
	    dialog.setUndecorated(true);
	    dialog.setSize(700, 400);
	    dialog.setLocationRelativeTo(this);
	    dialog.setLayout(new GridBagLayout()); // Cambiar a GridBagLayout

	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.fill = GridBagConstraints.HORIZONTAL;
	    gbc.insets = new Insets(15, 15, 15, 15); // Espaciado entre elementos
	    
	 // Fuente más grande para los textos
	    Font font = new Font("Arial", Font.PLAIN, 16);

	 // Crear los componentes del formulario
	    JLabel lblNombre = new JLabel("Nombre:");
	    lblNombre.setFont(font);
	    JTextField txtNombre = new JTextField(30); // Aumentar el tamaño del campo de texto

	    JLabel lblDescripcion = new JLabel("Descripción:");
	    lblDescripcion.setFont(font);
	 // Crear un JTextArea
	    JTextArea txtDescripcion = new JTextArea(5, 30); // 5 filas y 30 columnas
	    txtDescripcion.setFont(font);
	    txtDescripcion.setLineWrap(true); // Ajustar texto automáticamente
	    txtDescripcion.setWrapStyleWord(true); // Ajustar por palabra

	    // Agregar JScrollPane para desplazamiento
	    JScrollPane scrollDescripcion = new JScrollPane(txtDescripcion);
	    scrollDescripcion.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

	    // Añadir el JTextArea con desplazadores al diálogo
	    gbc.gridx = 1; gbc.gridy = 1;
	    dialog.add(scrollDescripcion, gbc);

	    JLabel lblFechaInicio = new JLabel("Fecha Inicio(YYYY-MM-DD):");
	    lblFechaInicio.setFont(font);
	    JTextField txtFechaInicio = new JTextField(30);

	    JLabel lblFechaFin = new JLabel("Fecha Fin(YYYY-MM-DD):");
	    lblFechaFin.setFont(font);
	    JTextField txtFechaFin = new JTextField(30);

	    JLabel lblUbicacion = new JLabel("Ubicación:");
	    lblUbicacion.setFont(font);
	    JTextField txtUbicacion = new JTextField(30);

	    JButton btnGuardar = new JButton("Guardar");
	    btnGuardar.setFont(font);
	    JButton btnCancelar = new JButton("Cancelar");
	    btnCancelar.setFont(font);

	  

	    // Agregar componentes al GridBagLayout
	    gbc.gridx = 0; gbc.gridy = 0;
	    dialog.add(lblNombre, gbc);
	    gbc.gridx = 1; 
	    dialog.add(txtNombre, gbc);

	    gbc.gridx = 0; gbc.gridy = 1;
	    dialog.add(lblDescripcion, gbc);
	    gbc.gridx = 1;
	    dialog.add(txtDescripcion, gbc);

	    gbc.gridx = 0; gbc.gridy = 2;
	    dialog.add(lblFechaInicio, gbc);
	    gbc.gridx = 1;
	    dialog.add(txtFechaInicio, gbc);

	    gbc.gridx = 0; gbc.gridy = 3;
	    dialog.add(lblFechaFin, gbc);
	    gbc.gridx = 1;
	    dialog.add(txtFechaFin, gbc);

	    gbc.gridx = 0; gbc.gridy = 4;
	    dialog.add(lblUbicacion, gbc);
	    gbc.gridx = 1;
	    dialog.add(txtUbicacion, gbc);

	    // Botones en la última fila
	    gbc.gridx = 0; gbc.gridy = 5;
	    dialog.add(btnGuardar, gbc);
	    gbc.gridx = 1;
	    dialog.add(btnCancelar, gbc);

		// Agregar ActionListener al botón Guardar
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
		            guardarEvento(
		                txtNombre.getText(),
		                txtDescripcion.getText(),
		                txtFechaInicio.getText(),
		                txtFechaFin.getText(),
		                txtUbicacion.getText()
		            );

		            JOptionPane.showMessageDialog(dialog, "Evento añadido con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
		            dialog.dispose();
		        } catch (IllegalArgumentException ex) {
		            JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Error", JOptionPane.WARNING_MESSAGE);
		        } catch (RuntimeException ex) {
		            JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		        }
			}
		});

		// Agregar ActionListener al botón Cancelar
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dialog.dispose(); // Cerrar el JDialog
			}
		});

		// Mostrar el JDialog
		dialog.setVisible(true);
		
	}

	
	
	private void MostrarEventos() {
		
		// Crear ventana para mostrar los eventos
	    JFrame frame = new JFrame("Lista de Eventos");
	    frame.setSize(600, 400);
	    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    frame.setLayout(new BorderLayout());

	    // Crear lista de eventos
	    DefaultListModel<String> model = new DefaultListModel<>();
	    JList<String> listaEventos = new JList<>(model);
	    listaEventos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    JScrollPane scrollPane = new JScrollPane(listaEventos);

	    // Botón para eliminar evento
	    JButton btnEliminar = new JButton("Eliminar Evento");
	    btnEliminar.setEnabled(false); // Deshabilitado inicialmente

	    // Habilitar el botón eliminar al seleccionar un elemento
	    listaEventos.addListSelectionListener(e -> {
	        btnEliminar.setEnabled(!listaEventos.isSelectionEmpty());
	    });

	    // Recuperar eventos de la base de datos usando tu conexión externa
	    String sql = "SELECT id_evento, nombre, descripcion, fecha_inicio, fecha_fin, ubicacion FROM eventos";

	    try (Connection conexion = Conexion.conectar();
	         PreparedStatement ps = conexion.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {
	            int id = rs.getInt("id_evento");
	            String nombre = rs.getString("nombre");
	            String descripcion = rs.getString("descripcion");
	            String fechaInicio = rs.getString("fecha_inicio");
	            String fechaFin = rs.getString("fecha_fin");
	            String ubicacion = rs.getString("ubicacion");

	            // Formatear cada evento con todos los datos
	            String evento = String.format(
	            	    "ID: %d\nNombre: %s\nDescripción: %s\nFecha Inicio: %s\nFecha Fin: %s\nUbicación: %s\n",
	            	    id, nombre, descripcion, fechaInicio, fechaFin, ubicacion
	            	);
	            model.addElement(evento); // Agregar al modelo de la lista
	        }

	    } catch (Exception ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(frame, "Error al recuperar los eventos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }

	    // Acción para eliminar evento
	    btnEliminar.addActionListener(e -> {
	        String eventoSeleccionado = listaEventos.getSelectedValue();
	        if (eventoSeleccionado != null) {
	            int idEvento = Integer.parseInt(eventoSeleccionado.split(": ")[1].split("\n")[0]); // Obtener el ID del evento

	            try (Connection conexion = Conexion.conectar();
	                 PreparedStatement ps = conexion.prepareStatement("DELETE FROM eventos WHERE id_evento = ?")) {

	                ps.setInt(1, idEvento);

	                int rowsDeleted = ps.executeUpdate();
	                if (rowsDeleted > 0) {
	                    JOptionPane.showMessageDialog(frame, "Evento eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
	                    model.removeElement(eventoSeleccionado); // Eliminar de la lista visual
	                }

	            } catch (Exception ex) {
	                ex.printStackTrace();
	                JOptionPane.showMessageDialog(frame, "Error al eliminar el evento: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	    });

	    // Agregar componentes al frame
	    frame.add(scrollPane, BorderLayout.CENTER);
	    frame.add(btnEliminar, BorderLayout.SOUTH);
	    frame.setVisible(true);
	}
	
	
	public void guardarEvento(String nombre, String descripcion, String fechaInicio, String fechaFin, String ubicacion) {
	    // Validación de los datos
	    if (nombre == null || nombre.isEmpty() || 
	        descripcion == null || descripcion.isEmpty() || 
	        fechaInicio == null || fechaInicio.isEmpty() || 
	        fechaFin == null || fechaFin.isEmpty() || 
	        ubicacion == null || ubicacion.isEmpty()) {
	        throw new IllegalArgumentException("Todos los campos deben estar completos.");
	    }

	    String sql = "INSERT INTO eventos (nombre, descripcion, fecha_inicio, fecha_fin, ubicacion) VALUES (?, ?, ?, ?, ?)";
	    try (Connection conexion = Conexion.conectar();
		         java.sql.PreparedStatement ps = conexion.prepareStatement(sql)) {
	        
	        // Consulta SQL para insertar los datos
	        
	        

	        // Asignar los valores a los parámetros
	    	ps.setString(1, nombre);
	    	ps.setString(2, descripcion);
	    	ps.setString(3, fechaInicio);
	        ps.setString(4, fechaFin);
	        ps.setString(5, ubicacion);

	        // Ejecutar la consulta
	        int rowsInserted = ps.executeUpdate();
	        if (rowsInserted > 0) {
	            System.out.println("Evento añadido correctamente.");
	        }

	        // Cerrar recursos
	        ps.close();
	        ps.close();
	    } catch (Exception ex) {
	        ex.printStackTrace();
	        throw new RuntimeException("Error al guardar el evento: " + ex.getMessage());
	    }
	}

}
