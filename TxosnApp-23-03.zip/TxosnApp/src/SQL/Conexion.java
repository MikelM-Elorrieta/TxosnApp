package SQL;

import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
	
        private static String url = "jdbc:mysql://localhost:3306/comision";
        private static String usuario = "root"; // Cambia según tu usuario
        private static String contraseña = "root";

        public static Connection conectar() {
        	try {
                // Cargar el driver de MySQL (opcional desde Java 8 en adelante)
                Class.forName("com.mysql.cj.jdbc.Driver");

                Class.forName("com.mysql.cj.jdbc.Driver");
                return DriverManager.getConnection(url, usuario, contraseña);

               
        	} catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
                return null;
            }
        }
    
}
