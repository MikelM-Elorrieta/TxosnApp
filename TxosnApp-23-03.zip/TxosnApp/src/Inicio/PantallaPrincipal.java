package Inicio;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

import Login.VistaLogin;

public class PantallaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PantallaPrincipal frame = new PantallaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PantallaPrincipal() {
		// Configuración básica del frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Pantalla completa
        setUndecorated(true); // Quita la barra de título

        // Establecer BorderLayout
        setLayout(new BorderLayout());

        // Crear JLabel para la imagen
        JLabel lblImagen = new JLabel();
        lblImagen.setHorizontalAlignment(JLabel.CENTER); // Centrar la imagen horizontalmente
        add(lblImagen, BorderLayout.CENTER);

        // Agregar un ComponentListener para ajustar la imagen cuando el JFrame esté visible
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                // Obtener el tamaño del JFrame
                int width = getWidth();
                int height = getHeight();

                // Redimensionar la imagen
                ImageIcon iconoOriginal = new ImageIcon("src/resources/tren_parke.png"); // Ruta de la imagen
                Image imagenRedimensionada = iconoOriginal.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
                lblImagen.setIcon(new ImageIcon(imagenRedimensionada));
            }
        });

        // Timer para cambiar al login después de 5 segundos
        Timer timer = new Timer(5000, e -> {
            VistaLogin login = new VistaLogin(); // Cambiar a la pantalla de login
            login.setVisible(true);
            dispose(); // Cerrar la pantalla principal
        });
        timer.setRepeats(false); // Ejecutar solo una vez
        timer.start();
	}

}
