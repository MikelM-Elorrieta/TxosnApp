package Inventario;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;

import Menu.VistaMenu;
import SQL.Conexion;

public class VistaAlcoholes extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    VistaAlcoholes frame = new VistaAlcoholes();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public VistaAlcoholes() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(240, 248, 255)); // Azul claro pastel (AliceBlue)

        // Crear los elementos del menú
        JMenuItem añadirAlcohol = new JMenuItem("AÑADIR ALCOHOL");
        añadirAlcohol.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        JMenuItem mostrarAlcoholes = new JMenuItem("MOSTRAR ALCOHOLES");
        mostrarAlcoholes.setFont(new Font("Segoe UI", Font.PLAIN, 16));

        menuBar.add(añadirAlcohol);
        menuBar.add(mostrarAlcoholes);

        setContentPane(contentPane);
        GridBagLayout gbl_contentPane = new GridBagLayout();
        gbl_contentPane.columnWidths = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        gbl_contentPane.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        gbl_contentPane.columnWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
                1.0, Double.MIN_VALUE };
        gbl_contentPane.rowWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE };
        contentPane.setLayout(gbl_contentPane);

        JButton btnVolver = new JButton("VOLVER");
        btnVolver.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnVolver.setBackground(new Color(176, 224, 230)); // Azul turquesa claro
        btnVolver.setForeground(Color.BLACK);
        btnVolver.setPreferredSize(new java.awt.Dimension(150, 50)); // Tamaño uniforme
        GridBagConstraints gbc_btnVolver = new GridBagConstraints();
        gbc_btnVolver.gridx = 13;
        gbc_btnVolver.gridy = 7;
        contentPane.add(btnVolver, gbc_btnVolver);

        btnVolver.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                VistaInventario vistaInventario = new VistaInventario();
                vistaInventario.setVisible(true);
                dispose();
            }
        });

        añadirAlcohol.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                FormularioAñadirAlcohol();
            }
        });

        mostrarAlcoholes.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarAlcoholes();
            }
        });
    }

    private void FormularioAñadirAlcohol() {
    	// Limpiar el contenido actual de la ventana principal (contentPane)
        contentPane.removeAll();
        contentPane.setLayout(new GridLayout(5, 3)); // Configurar nuevo diseño para el formulario
        contentPane.setBackground(new Color(245, 245, 245)); // Fondo gris claro

        // Crear los componentes del formulario
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JTextField txtNombre = new JTextField();

        JLabel lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JTextField txtCantidad = new JTextField();

        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JTextField txtPrecio = new JTextField();

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(new Color(144, 238, 144)); // Verde claro

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCancelar.setBackground(new Color(255, 160, 122)); // Coral claro

        // Agregar los componentes al contentPane
        contentPane.add(lblNombre);
        contentPane.add(txtNombre);
        contentPane.add(lblCantidad);
        contentPane.add(txtCantidad);
        contentPane.add(lblPrecio);
        contentPane.add(txtPrecio);
        contentPane.add(new JLabel()); // Espacio vacío
        contentPane.add(btnGuardar);
        contentPane.add(btnCancelar);

        // Actualizar visualmente el contentPane
        contentPane.revalidate();
        contentPane.repaint();

        // Acción del botón "Guardar"
        btnGuardar.addActionListener(e -> {
            String nombre = txtNombre.getText();
            int cantidad = Integer.parseInt(txtCantidad.getText());
            double precio = Double.parseDouble(txtPrecio.getText());
            guardarAlcohol(nombre, cantidad, precio);
            JOptionPane.showMessageDialog(this, "Alcohol añadido: " + nombre);
            mostrarAlcoholes(); // Volver a mostrar la lista después de añadir
        });

        // Acción del botón "Cancelar"
        btnCancelar.addActionListener(e -> mostrarAlcoholes());
     
    }

    private void mostrarAlcoholes() {
        // Crear un panel para mostrar las bebidas alcohólicas
        JPanel panelAlcoholes = new JPanel();
        panelAlcoholes.setLayout(new BorderLayout());
        panelAlcoholes.setBackground(new Color(240, 248, 255)); // Fondo azul claro pastel

        // Crear lista de bebidas alcohólicas
        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> listaBebidas = new JList<>(model);
        listaBebidas.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(listaBebidas);

        // Botón para eliminar bebida
        JButton btnEliminar = new JButton("Eliminar Bebida");
        btnEliminar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnEliminar.setBackground(new Color(255, 182, 193)); // Rosado claro
        btnEliminar.setEnabled(false); // Deshabilitado inicialmente

        // Habilitar el botón eliminar al seleccionar un elemento
        listaBebidas.addListSelectionListener(e -> btnEliminar.setEnabled(!listaBebidas.isSelectionEmpty()));

        // Recuperar bebidas alcohólicas de la base de datos
        String sql = "SELECT id_bebida, nombre, cantidad, precio_venta FROM bebidas WHERE tipo = 'alcohólica'";

        try (Connection conexion = Conexion.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id_bebida");
                String nombre = rs.getString("nombre");
                int volumen = rs.getInt("cantidad");
                double precioVenta = rs.getDouble("precio_venta");

                // Formatear cada bebida con sus datos
                String bebida = "ID: " + id + " | Nombre: " + nombre + " | Cantidad: " + volumen + " ml | Precio: €" + precioVenta;
                model.addElement(bebida); // Agregar al modelo de la lista
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al recuperar las bebidas: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Acción para eliminar bebida
        btnEliminar.addActionListener(e -> {
            String bebidaSeleccionada = listaBebidas.getSelectedValue();
            if (bebidaSeleccionada != null) {
                int idBebida = Integer.parseInt(bebidaSeleccionada.split(": ")[1].split(" \\|")[0]); // Obtener el ID de la bebida

                try (Connection conexion = Conexion.conectar();
                     PreparedStatement ps = conexion.prepareStatement("DELETE FROM bebidas WHERE id_bebida = ?")) {

                    ps.setInt(1, idBebida);

                    int rowsDeleted = ps.executeUpdate();
                    if (rowsDeleted > 0) {
                        JOptionPane.showMessageDialog(this, "Bebida eliminada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        model.removeElement(bebidaSeleccionada); // Eliminar de la lista visual
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al eliminar la bebida: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Agregar componentes al panel
        panelAlcoholes.add(scrollPane, BorderLayout.CENTER);
        panelAlcoholes.add(btnEliminar, BorderLayout.SOUTH);

        // Mostrar el panel en el centro de la ventana principal
        contentPane.removeAll(); // Limpiar la ventana principal
        contentPane.setLayout(new BorderLayout());
        contentPane.add(panelAlcoholes, BorderLayout.CENTER);
        contentPane.revalidate(); // Refrescar el contenido
        contentPane.repaint(); // Actualizar la interfaz visual
    }


    private void guardarAlcohol(String nombre, int cantidad, double precio) {
        String tipo = "alcohólica";

        String sql = "INSERT INTO bebidas (nombre, tipo, cantidad, precio_venta) VALUES (?, ?, ?, ?)";
        try (Connection conexion = Conexion.conectar(); PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setString(2, tipo);
            ps.setInt(3, cantidad);
            ps.setDouble(4, precio);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "¡Alcohol añadido exitosamente!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al guardar el alcohol: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
