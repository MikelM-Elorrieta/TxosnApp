package Comisarios;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Menu.VistaMenu;

import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;

public class VistaComisarios extends JFrame {

	private List<String> usuarios;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaComisarios frame = new VistaComisarios();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaComisarios() {

		usuarios = new ArrayList<>();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		// Crear los elementos del menú
		JMenuItem añadirComisario = new JMenuItem("AÑADIR COMISARIO");
		JMenuItem mostrarComisarios = new JMenuItem("MOSTRAR COMISARIOS");
		JMenuItem gestionarComisario = new JMenuItem("GESTIONAR COMISARIO");
		menuBar.add(añadirComisario);
		menuBar.add(mostrarComisarios);
		menuBar.add(gestionarComisario);

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.columnWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
				0.0, Double.MIN_VALUE };
		gbl_contentPane.rowWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE };
		contentPane.setLayout(gbl_contentPane);

		JButton btnVolver = new JButton("VOLVER");
		GridBagConstraints gbc_btnVolver = new GridBagConstraints();
		gbc_btnVolver.gridx = 13;
		gbc_btnVolver.gridy = 6;
		contentPane.add(btnVolver, gbc_btnVolver);

		// Agregar ActionListeners a los elementos del menú
		añadirComisario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mostrar el formulario de añadir usuario
				mostrarFormularioAñadirUsuario();
			}

		});

		// Agregar ActionListeners a los elementos del menú
		mostrarComisarios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mostrar el formulario de añadir usuario
				mostrarUsuarios();
			}

		});

		gestionarComisario.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				gestionarUsuarios();

			}

		});

		btnVolver.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaMenu vistaMenu = new VistaMenu();
				vistaMenu.setVisible(true);
				dispose();

			}

		});
	}

	private void mostrarFormularioAñadirUsuario() {
		// Crear el JDialog para el formulario
		JDialog dialog = new JDialog(this, "Añadir Usuario", true);

		dialog.setUndecorated(true); // Eliminar bordes y barra de título

		// Configurar el tamaño del JDialog para que ocupe toda la pantalla
		dialog.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		dialog.setLocationRelativeTo(null);

		dialog.setSize(500, 300);
		dialog.getContentPane().setLayout(new GridLayout(4, 2));
		dialog.setLocationRelativeTo(this);

		// Crear los componentes del formulario
		JLabel lblNombre = new JLabel("Nombre:");
		JTextField txtNombre = new JTextField();
		JLabel lblApellido = new JLabel("Apellido:");
		JTextField txtApellido = new JTextField();

		JButton btnGuardar = new JButton("Guardar");
		JButton btnCancelar = new JButton("Cancelar");

		// Agregar los componentes al JDialog
		dialog.getContentPane().add(lblNombre);
		dialog.getContentPane().add(txtNombre);
		dialog.getContentPane().add(lblApellido);
		dialog.getContentPane().add(txtApellido);

		dialog.getContentPane().add(new JLabel()); // Espacio vacío
		dialog.getContentPane().add(btnGuardar);
		dialog.add(btnCancelar);

		// Agregar ActionListener al botón Guardar
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Aquí puedes agregar la lógica para guardar el usuario
				String nombre = txtNombre.getText();
				String apellido = txtApellido.getText();

				JOptionPane.showMessageDialog(dialog, "Usuario añadido: " + nombre + " " + apellido);
				dialog.dispose();
			}
		});
		
		// Agregar ActionListener al botón Cancelar
        btnCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose(); // Cerrar el JDialog
            }
        });

		// Mostrar el JDialog
		dialog.setVisible(true);

	}

	private void mostrarUsuarios() {

		// Crear un mensaje con la lista de usuarios
		StringBuilder mensaje = new StringBuilder("Usuarios guardados:\n");
		for (String usuario : usuarios) {
			mensaje.append(usuario).append("\n");
		}

		// Mostrar el mensaje en un cuadro de diálogo
		JOptionPane.showMessageDialog(this, mensaje.toString(), "Lista de Usuarios", JOptionPane.INFORMATION_MESSAGE);
	}

	private void gestionarUsuarios() {
		// Crear el JDialog para el formulario
		JDialog dialog = new JDialog(this, "Añadir Usuario", true);

		dialog.setUndecorated(true); // Eliminar bordes y barra de título

		// Configurar el tamaño del JDialog para que ocupe toda la pantalla
		dialog.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		dialog.setLocationRelativeTo(null);

		dialog.setSize(500, 300);
		dialog.getContentPane().setLayout(new GridLayout(4, 2));
		dialog.setLocationRelativeTo(this);

		// Crear los componentes del formulario
		JLabel lblNombre = new JLabel("Nombre:");
		JTextField txtNombre = new JTextField();
		JLabel lblApellido = new JLabel("Apellido:");
		JTextField txtApellido = new JTextField();

		JButton btnGuardar = new JButton("Guardar");
		JButton btnCancelar = new JButton("Cancelar");

		// Agregar los componentes al JDialog
		dialog.getContentPane().add(lblNombre);
		dialog.getContentPane().add(txtNombre);
		dialog.getContentPane().add(lblApellido);
		dialog.getContentPane().add(txtApellido);

		dialog.getContentPane().add(new JLabel()); // Espacio vacío
		dialog.getContentPane().add(btnGuardar);
		dialog.add(btnCancelar);

		// Agregar ActionListener al botón Guardar
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Aquí puedes agregar la lógica para guardar el usuario
				String nombre = txtNombre.getText();
				String apellido = txtApellido.getText();

				JOptionPane.showMessageDialog(dialog, "Usuario añadido: " + nombre + " " + apellido);
				dialog.dispose();
			}
		});
		
		// Agregar ActionListener al botón Cancelar
        btnCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose(); // Cerrar el JDialog
            }
        });

		// Mostrar el JDialog
		dialog.setVisible(true);
	}

}
