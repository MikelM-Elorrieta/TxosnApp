package Inventario;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSpinner;
import javax.swing.JTextField;

import java.awt.Insets;
import java.awt.Toolkit;

import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.JDialog;

public class VistaPrendas extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaPrendas frame = new VistaPrendas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaPrendas() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		// Crear los elementos del menú
		JMenuItem añadirPrenda = new JMenuItem("AÑADIR PRENDA");
		JMenuItem mostrarPrendas = new JMenuItem("MOSTRAR PRENDAS");

		menuBar.add(añadirPrenda);
		menuBar.add(mostrarPrendas);

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.columnWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
				1.0, Double.MIN_VALUE };
		gbl_contentPane.rowWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE };
		contentPane.setLayout(gbl_contentPane);

		JButton btnVolver = new JButton("VOLVER");
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridx = 13;
		gbc_btnNewButton.gridy = 7;
		contentPane.add(btnVolver, gbc_btnNewButton);

		btnVolver.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaInventario vistaInventario = new VistaInventario();
				vistaInventario.setVisible(true);
				dispose();

			}

		});

		añadirPrenda.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				Combobox();

			}

		});

	}

	private void Combobox() {
		// Crear el JDialog para el formulario
		JDialog dialog = new JDialog(this, "Añadir Refresco", true);

		dialog.setUndecorated(true); // Eliminar bordes y barra de título

		// Configurar el tamaño del JDialog para que ocupe toda la pantalla
		dialog.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		dialog.setLocationRelativeTo(null);

		dialog.setSize(500, 300);
		dialog.getContentPane().setLayout(new GridLayout(5, 3));
		dialog.setLocationRelativeTo(this);

		// Crear el JComboBox con opciones
		String[] opciones = { "CAMISETAS", "PAÑUELOS", "TOTEBAGS" };
		JComboBox<String> comboBox = new JComboBox<>(opciones);

		// Crear el botón para confirmar la selección
		JButton btnSeleccionar = new JButton("Seleccionar");

		btnSeleccionar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				String seleccion = (String) comboBox.getSelectedItem();

				if (seleccion.equals("CAMISETAS")) {
					dialog.dispose();
					frameCamisetas();

				} else if (seleccion.equals("PAÑUELOS")) {
					dialog.dispose();
					framePañuelos();

				} else if (seleccion.equals("TOTEBAGS")) {
					dialog.dispose();
					frameTotebags();
				}

			}

		});

		// Agregar el JComboBox y el botón al JDialog
		dialog.add(comboBox);
		dialog.add(btnSeleccionar);

		// Mostrar el JDialog
		dialog.setVisible(true);

	}

	public static void frameCamisetas() {
		
		JFrame nuevoFrameCamisetas = new JFrame();
		nuevoFrameCamisetas.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		nuevoFrameCamisetas.setSize(400, 300);
		nuevoFrameCamisetas.setLocationRelativeTo(null);
		nuevoFrameCamisetas.setVisible(true);

		// Crear los componentes del formulario
		JLabel lblNombre = new JLabel("Nombre:");
		JTextField txtNombre = new JTextField();
		JLabel lblCantidad = new JLabel("Cantidad:");
		JTextField txtCantidad = new JTextField();
		JLabel lblPrecio = new JLabel("Precio:");
		JTextField txtPrecio = new JTextField();

		// Crear el JComboBox con opciones
		String[] tamañosCamisetas = { "XS", "S", "M", "L", "XL" };
		JComboBox<String> comboBox = new JComboBox<>(tamañosCamisetas);
		String seleccion = (String) comboBox.getSelectedItem();

		JButton btnGuardar = new JButton("Guardar");
		JButton btnCancelar = new JButton("Cancelar");

		// Agregar los componentes al JDialog
		nuevoFrameCamisetas.getContentPane().add(lblNombre);
		nuevoFrameCamisetas.getContentPane().add(txtNombre);
		nuevoFrameCamisetas.getContentPane().add(lblCantidad);
		nuevoFrameCamisetas.getContentPane().add(txtCantidad);
		nuevoFrameCamisetas.getContentPane().add(lblPrecio);
		nuevoFrameCamisetas.getContentPane().add(txtPrecio);
		nuevoFrameCamisetas.getContentPane().add(comboBox);

		nuevoFrameCamisetas.getContentPane().add(new JLabel()); // Espacio vacío
		nuevoFrameCamisetas.getContentPane().add(btnGuardar);
		nuevoFrameCamisetas.add(btnCancelar);
	}

	public static void framePañuelos() {

		JFrame nuevoFramePañuelos = new JFrame();
		nuevoFramePañuelos.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		nuevoFramePañuelos.setSize(400, 300);
		nuevoFramePañuelos.setLocationRelativeTo(null);
		nuevoFramePañuelos.setVisible(true);

		// Crear los componentes del formulario
		JLabel lblNombre = new JLabel("Nombre:");
		JTextField txtNombre = new JTextField();
		JLabel lblCantidad = new JLabel("Cantidad:");
		JTextField txtCantidad = new JTextField();
		JLabel lblPrecio = new JLabel("Precio:");
		JTextField txtPrecio = new JTextField();

		JButton btnGuardar = new JButton("Guardar");
		JButton btnCancelar = new JButton("Cancelar");

		// Agregar los componentes al JDialog
		nuevoFramePañuelos.getContentPane().add(lblNombre);
		nuevoFramePañuelos.getContentPane().add(txtNombre);
		nuevoFramePañuelos.getContentPane().add(lblCantidad);
		nuevoFramePañuelos.getContentPane().add(txtCantidad);
		nuevoFramePañuelos.getContentPane().add(lblPrecio);
		nuevoFramePañuelos.getContentPane().add(txtPrecio);

		nuevoFramePañuelos.getContentPane().add(new JLabel()); // Espacio vacío
		nuevoFramePañuelos.getContentPane().add(btnGuardar);
		nuevoFramePañuelos.add(btnCancelar);
	}

	public static void frameTotebags() {
		JFrame nuevoFrameTotebags = new JFrame();
		nuevoFrameTotebags.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		nuevoFrameTotebags.setSize(400, 300);
		nuevoFrameTotebags.setLocationRelativeTo(null);
		nuevoFrameTotebags.setVisible(true);

		// Crear los componentes del formulario
		JLabel lblNombre = new JLabel("Nombre:");
		JTextField txtNombre = new JTextField();
		JLabel lblCantidad = new JLabel("Cantidad:");
		JTextField txtCantidad = new JTextField();
		JLabel lblPrecio = new JLabel("Precio:");
		JTextField txtPrecio = new JTextField();

		JButton btnGuardar = new JButton("Guardar");
		JButton btnCancelar = new JButton("Cancelar");

		// Agregar los componentes al JDialog
		nuevoFrameTotebags.getContentPane().add(lblNombre);
		nuevoFrameTotebags.getContentPane().add(txtNombre);
		nuevoFrameTotebags.getContentPane().add(lblCantidad);
		nuevoFrameTotebags.getContentPane().add(txtCantidad);
		nuevoFrameTotebags.getContentPane().add(lblPrecio);
		nuevoFrameTotebags.getContentPane().add(txtPrecio);

		nuevoFrameTotebags.getContentPane().add(new JLabel()); // Espacio vacío
		nuevoFrameTotebags.getContentPane().add(btnGuardar);
		nuevoFrameTotebags.add(btnCancelar);
	}

}
