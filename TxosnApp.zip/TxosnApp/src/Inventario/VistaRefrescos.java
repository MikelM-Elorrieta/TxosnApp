package Inventario;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class VistaRefrescos extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaRefrescos frame = new VistaRefrescos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaRefrescos() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		// Crear los elementos del menú
		JMenuItem añadirRefresco = new JMenuItem("AÑADIR REFRESCO");
		JMenuItem mostrarRefrescos = new JMenuItem("MOSTRAR REFRESCOS");

		menuBar.add(añadirRefresco);
		menuBar.add(mostrarRefrescos);

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.columnWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
				1.0, Double.MIN_VALUE };
		gbl_contentPane.rowWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE };
		contentPane.setLayout(gbl_contentPane);

		JButton btnVolver = new JButton("VOLVER");
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridx = 13;
		gbc_btnNewButton.gridy = 7;
		contentPane.add(btnVolver, gbc_btnNewButton);

		btnVolver.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaInventario vistaInventario = new VistaInventario();
				vistaInventario.setVisible(true);
				dispose();

			}

		});

		añadirRefresco.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				FormularioAñadirRefresco();

			}

		});

		mostrarRefrescos.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				mostrarRefrescos();

			}

		});
	}
	
	private void FormularioAñadirRefresco() {
		// Crear el JDialog para el formulario
		JDialog dialog = new JDialog(this, "Añadir Refresco", true);

		dialog.setUndecorated(true); // Eliminar bordes y barra de título

		// Configurar el tamaño del JDialog para que ocupe toda la pantalla
		dialog.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		dialog.setLocationRelativeTo(null);

		dialog.setSize(500, 300);
		dialog.getContentPane().setLayout(new GridLayout(5, 3));
		dialog.setLocationRelativeTo(this);

		// Crear los componentes del formulario
		JLabel lblNombre = new JLabel("Nombre:");
		JTextField txtNombre = new JTextField();
		JLabel lblCantidad = new JLabel("Cantidad:");
		JTextField txtCantidad = new JTextField();
		JLabel lblPrecio = new JLabel("Precio:");
		JTextField txtPrecio = new JTextField();

		JButton btnGuardar = new JButton("Guardar");
		JButton btnCancelar = new JButton("Cancelar");

		// Agregar los componentes al JDialog
		dialog.getContentPane().add(lblNombre);
		dialog.getContentPane().add(txtNombre);
		dialog.getContentPane().add(lblCantidad);
		dialog.getContentPane().add(txtCantidad);
		dialog.getContentPane().add(lblPrecio);
		dialog.getContentPane().add(txtPrecio);
		


		dialog.getContentPane().add(new JLabel()); // Espacio vacío
		dialog.getContentPane().add(btnGuardar);
		dialog.add(btnCancelar);

		// Agregar ActionListener al botón Guardar
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Aquí puedes agregar la lógica para guardar el usuario
				String nombre = txtNombre.getText();
				String textCantidad = lblCantidad.getText();
				int cantidad = Integer.parseInt(textCantidad);
				String textPrecio = lblPrecio.getText();
				int precio = Integer.parseInt(textPrecio);
				
				JOptionPane.showMessageDialog(dialog, "Usuario añadido: " + nombre + " " + cantidad);
				dialog.dispose();
			}
		});

		// Agregar ActionListener al botón Cancelar
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dialog.dispose(); // Cerrar el JDialog
			}
		});

		// Mostrar el JDialog
		dialog.setVisible(true);

	}

	private void mostrarRefrescos() {
		// TODO Auto-generated method stub

	}

}
