/**
 * 
 */
/**
 * 
 */
module TxosnApp {
	requires java.desktop;
}