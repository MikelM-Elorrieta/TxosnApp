package Login;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

import Menu.VistaMenu;
import SQL.Conexion;

import java.awt.GridBagLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import javax.swing.JTextField;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class VistaLogin extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtUsuario;
	private JPasswordField txtContraseña;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaLogin frame = new VistaLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(176, 224, 230)); // Azul claro suave
        setContentPane(contentPane);

        GridBagLayout gbl_contentPane = new GridBagLayout();
        gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0};
        gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0};
        gbl_contentPane.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
        gbl_contentPane.rowWeights = new double[]{1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
        contentPane.setLayout(gbl_contentPane);

        JLabel lblNewLabel = new JLabel("USUARIO");
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 18));
        lblNewLabel.setForeground(new Color(47, 79, 79)); // Gris oscuro
        GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
        gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
        gbc_lblNewLabel.gridx = 1;
        gbc_lblNewLabel.gridy = 1;
        contentPane.add(lblNewLabel, gbc_lblNewLabel);

        txtUsuario = new JTextField();
        txtUsuario.setFont(new Font("Arial", Font.PLAIN, 16));
        txtUsuario.setBackground(new Color(240, 255, 255)); // Blanco turquesa muy claro
        txtUsuario.setForeground(Color.BLACK);
        GridBagConstraints gbc_txtUsuario = new GridBagConstraints();
        gbc_txtUsuario.insets = new Insets(0, 0, 5, 5);
        gbc_txtUsuario.fill = GridBagConstraints.HORIZONTAL;
        gbc_txtUsuario.gridx = 2;
        gbc_txtUsuario.gridy = 1;
        contentPane.add(txtUsuario, gbc_txtUsuario);
        txtUsuario.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("CONTRASEÑA");
        lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 18));
        lblNewLabel_1.setForeground(new Color(47, 79, 79)); // Gris oscuro
        GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
        gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
        gbc_lblNewLabel_1.gridx = 1;
        gbc_lblNewLabel_1.gridy = 2;
        contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);

        txtContraseña = new JPasswordField();
        txtContraseña.setFont(new Font("Arial", Font.PLAIN, 16));
        txtContraseña.setBackground(new Color(240, 255, 255)); // Blanco turquesa muy claro
        txtContraseña.setForeground(Color.BLACK);
        GridBagConstraints gbc_txtContraseña = new GridBagConstraints();
        gbc_txtContraseña.insets = new Insets(0, 0, 5, 5);
        gbc_txtContraseña.fill = GridBagConstraints.HORIZONTAL;
        gbc_txtContraseña.gridx = 2;
        gbc_txtContraseña.gridy = 2;
        contentPane.add(txtContraseña, gbc_txtContraseña);
        txtContraseña.setColumns(10);

        JButton btnLogin = new JButton("LOGIN");
        btnLogin.setFont(new Font("Arial", Font.BOLD, 16)); // Fuente más pequeña
        btnLogin.setBackground(new Color(216, 191, 216)); // Lavanda suave
        btnLogin.setForeground(Color.BLACK);
        btnLogin.setPreferredSize(new java.awt.Dimension(150, 50)); // Tamaño más grande del botón
        GridBagConstraints gbc_btnLogin = new GridBagConstraints();
        gbc_btnLogin.gridx = 4;
        gbc_btnLogin.gridy = 3;
        contentPane.add(btnLogin, gbc_btnLogin);
        
        
        JLabel lblImagen = new JLabel();
        ImageIcon icono = new ImageIcon("src/resources/escudo.png");
        Image imagenRedimensionada = icono.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        lblImagen.setIcon(new ImageIcon(imagenRedimensionada));

        GridBagConstraints gbc_lblImagen = new GridBagConstraints();
        gbc_lblImagen.gridx = 2;
        gbc_lblImagen.gridy = 0;
        gbc_lblImagen.insets = new Insets(10, 10, 10, 10);
        contentPane.add(lblImagen, gbc_lblImagen);
		
		//Boton Login
		btnLogin.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String usuario = txtUsuario.getText();
				String contraseña = new String(txtContraseña.getPassword());

				
				if (autenticarUsuario(usuario, contraseña)) {
		            VistaMenu vistaMenu = new VistaMenu();
		            vistaMenu.setVisible(true);
		            dispose();
		        } else {
		            JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Advertencia", JOptionPane.WARNING_MESSAGE);
		        }
				
				
			}
			
		});
	}
	
	private boolean autenticarUsuario(String usuario, String contraseña) {
	    String sql = "SELECT * FROM usuario WHERE nombre_usuario = ? AND contraseña = ?";

	    try (Connection conexion = Conexion.conectar();
	         java.sql.PreparedStatement ps = conexion.prepareStatement(sql)) {

	        ps.setString(1, usuario);
	        ps.setString(2, contraseña);
	        java.sql.ResultSet rs = ps.executeQuery();

	        return rs.next(); // Si hay resultados, el usuario es válido.

	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }
	}

}
