package Inventario;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import SQL.Conexion;

public class VistaRefrescos extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaRefrescos frame = new VistaRefrescos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaRefrescos() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		// Crear los elementos del menú
		JMenuItem añadirRefresco = new JMenuItem("AÑADIR REFRESCO");
		JMenuItem mostrarRefrescos = new JMenuItem("MOSTRAR REFRESCOS");

		menuBar.add(añadirRefresco);
		menuBar.add(mostrarRefrescos);

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.columnWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
				1.0, Double.MIN_VALUE };
		gbl_contentPane.rowWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE };
		contentPane.setLayout(gbl_contentPane);

		JButton btnVolver = new JButton("VOLVER");
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridx = 13;
		gbc_btnNewButton.gridy = 7;
		contentPane.add(btnVolver, gbc_btnNewButton);

		btnVolver.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaInventario vistaInventario = new VistaInventario();
				vistaInventario.setVisible(true);
				dispose();

			}

		});

		añadirRefresco.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				FormularioAñadirRefresco();

			}

		});

		mostrarRefrescos.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				mostrarRefrescos();

			}

		});
	}
	
	private void FormularioAñadirRefresco() {
		// Crear el JDialog para el formulario
		JDialog dialog = new JDialog(this, "Añadir Refresco", true);

		dialog.setUndecorated(true); // Eliminar bordes y barra de título

		// Configurar el tamaño del JDialog para que ocupe toda la pantalla
		dialog.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		dialog.setLocationRelativeTo(null);

		dialog.setSize(500, 300);
		dialog.getContentPane().setLayout(new GridLayout(5, 3));
		dialog.setLocationRelativeTo(this);

		// Crear los componentes del formulario
		JLabel lblNombre = new JLabel("Nombre:");
		JTextField txtNombre = new JTextField();
		JLabel lblCantidad = new JLabel("Cantidad:");
		JTextField txtCantidad = new JTextField();
		JLabel lblPrecio = new JLabel("Precio:");
		JTextField txtPrecio = new JTextField();

		JButton btnGuardar = new JButton("Guardar");
		JButton btnCancelar = new JButton("Cancelar");

		// Agregar los componentes al JDialog
		dialog.getContentPane().add(lblNombre);
		dialog.getContentPane().add(txtNombre);
		dialog.getContentPane().add(lblCantidad);
		dialog.getContentPane().add(txtCantidad);
		dialog.getContentPane().add(lblPrecio);
		dialog.getContentPane().add(txtPrecio);
		


		dialog.getContentPane().add(new JLabel()); // Espacio vacío
		dialog.getContentPane().add(btnGuardar);
		dialog.add(btnCancelar);

		// Agregar ActionListener al botón Guardar
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try {
		            // Obtener los datos del formulario
		            String nombre = txtNombre.getText().trim();
		            int volumen = Integer.parseInt(txtCantidad.getText().trim());
		            double precioVenta = Double.parseDouble(txtPrecio.getText().trim());

		            // Validar que los campos no estén vacíos
		            if (nombre.isEmpty()) {
		                JOptionPane.showMessageDialog(dialog, "El nombre no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
		                return;
		            }

		            if (volumen <= 0 || precioVenta <= 0) {
		                JOptionPane.showMessageDialog(dialog, "Volumen y precio deben ser mayores que 0.", "Error", JOptionPane.ERROR_MESSAGE);
		                return;
		            }

		            // Llamar al método para guardar el refresco
		            guardarRefresco(nombre, volumen, precioVenta);

		            // Cerrar el formulario tras guardar exitosamente
		            dialog.dispose();

		        } catch (NumberFormatException ex) {
		            JOptionPane.showMessageDialog(dialog, "Por favor, introduce valores numéricos válidos para Volumen y Precio.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
		        } catch (Exception ex) {
		            JOptionPane.showMessageDialog(dialog, "Ocurrió un error al guardar el refresco: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		            ex.printStackTrace();
		        }
		    }
		});

		// Agregar ActionListener al botón Cancelar
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dialog.dispose(); // Cerrar el JDialog
			}
		});

		// Mostrar el JDialog
		dialog.setVisible(true);

	}
	
	private void guardarRefresco(String nombre, int volumen, double precioVenta) {
	    String tipo = "no alcohólica"; // Establecer el tipo fijo como Refresco

	    String sql = "INSERT INTO bebidas (nombre, tipo, cantidad, precio_venta) VALUES (?, ?, ?, ?)";

	    try (Connection conexion = Conexion.conectar();
	         PreparedStatement ps = conexion.prepareStatement(sql)) {

	        // Configurar los parámetros de la consulta
	        ps.setString(1, nombre);
	        ps.setString(2, tipo);
	        ps.setInt(3, volumen);
	        ps.setDouble(4, precioVenta);

	        // Ejecutar la consulta
	        int filasInsertadas = ps.executeUpdate();
	        if (filasInsertadas > 0) {
	            JOptionPane.showMessageDialog(this, "¡Refresco añadido exitosamente!");
	        }
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error al guardar el refresco: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	        e.printStackTrace();
	    }
	}

	private void mostrarRefrescos() {
		 // Crear ventana para mostrar los refrescos
	    JFrame frame = new JFrame("Lista de Refrescos");
	    frame.setSize(600, 400);
	    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    frame.setLayout(new BorderLayout());

	    // Crear lista de refrescos
	    DefaultListModel<String> model = new DefaultListModel<>();
	    JList<String> listaRefrescos = new JList<>(model);
	    listaRefrescos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    JScrollPane scrollPane = new JScrollPane(listaRefrescos);

	    // Botón para eliminar refresco
	    JButton btnEliminar = new JButton("Eliminar Refresco");
	    btnEliminar.setEnabled(false); // Deshabilitado inicialmente

	    // Habilitar el botón eliminar al seleccionar un elemento
	    listaRefrescos.addListSelectionListener(e -> {
	        btnEliminar.setEnabled(!listaRefrescos.isSelectionEmpty());
	    });

	    // Recuperar refrescos de la base de datos usando un filtro
	    String sql = "SELECT id_bebida, nombre, cantidad, precio_venta FROM bebidas WHERE tipo = 'no alcohólica'";

	    try (Connection conexion = Conexion.conectar();
	         PreparedStatement ps = conexion.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {
	            int id = rs.getInt("id_bebida");
	            String nombre = rs.getString("nombre");
	            int volumen = rs.getInt("cantidad");
	            double precioVenta = rs.getDouble("precio_venta");

	            // Formatear cada refresco con los datos
	            String refresco = "ID: " + id + " | Nombre: " + nombre + " | Cantidad: " + volumen + " ml | Precio: €" + precioVenta;
	            model.addElement(refresco); // Agregar al modelo de la lista
	        }

	    } catch (Exception ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(frame, "Error al recuperar los refrescos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }

	    // Acción para eliminar refresco
	    btnEliminar.addActionListener(e -> {
	        String refrescoSeleccionado = listaRefrescos.getSelectedValue();
	        if (refrescoSeleccionado != null) {
	            int idBebida = Integer.parseInt(refrescoSeleccionado.split(": ")[1].split(" \\|")[0]); // Obtener el ID del refresco

	            try (Connection conexion = Conexion.conectar();
	                 PreparedStatement ps = conexion.prepareStatement("DELETE FROM bebidas WHERE id_bebida = ?")) {

	                ps.setInt(1, idBebida);

	                int rowsDeleted = ps.executeUpdate();
	                if (rowsDeleted > 0) {
	                    JOptionPane.showMessageDialog(frame, "Refresco eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
	                    model.removeElement(refrescoSeleccionado); // Eliminar de la lista visual
	                }

	            } catch (Exception ex) {
	                ex.printStackTrace();
	                JOptionPane.showMessageDialog(frame, "Error al eliminar el refresco: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	    });

	    // Agregar componentes al frame
	    frame.add(scrollPane, BorderLayout.CENTER);
	    frame.add(btnEliminar, BorderLayout.SOUTH);
	    frame.setVisible(true);

	}

}
