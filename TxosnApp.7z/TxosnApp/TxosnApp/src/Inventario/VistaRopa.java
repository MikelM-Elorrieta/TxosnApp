package Inventario;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import SQL.Conexion;

import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;

import java.awt.Insets;
import java.awt.Toolkit;

import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.JDialog;

public class VistaRopa extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaRopa frame = new VistaRopa();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaRopa() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		// Crear los elementos del menú
		JMenuItem añadirPrenda = new JMenuItem("AÑADIR PRENDA");
		JMenuItem mostrarPrendas = new JMenuItem("MOSTRAR PRENDAS");

		menuBar.add(añadirPrenda);
		menuBar.add(mostrarPrendas);

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.columnWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
				1.0, Double.MIN_VALUE };
		gbl_contentPane.rowWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE };
		contentPane.setLayout(gbl_contentPane);

		JButton btnVolver = new JButton("VOLVER");
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridx = 13;
		gbc_btnNewButton.gridy = 7;
		contentPane.add(btnVolver, gbc_btnNewButton);

		btnVolver.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaInventario vistaInventario = new VistaInventario();
				vistaInventario.setVisible(true);
				dispose();

			}

		});

		añadirPrenda.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				OpcionesPrendas();
					
			}
		});
		
		mostrarPrendas.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				mostrarPrendas();
					
			}
		});

	}

	
	private void OpcionesPrendas() {
		JDialog dialog = new JDialog();
	    dialog.setUndecorated(true); // Eliminar bordes y barra de título
	    dialog.setSize(Toolkit.getDefaultToolkit().getScreenSize()); // Inicializar en pantalla completa
	    dialog.setLocationRelativeTo(null);
	    dialog.setLayout(new GridLayout(5, 1, 10, 10)); // Configurar diseño con espacio entre componentes

	    // Fuente moderna
	    Font modernFont = new Font("Segoe UI", Font.BOLD, 18);

	    // Crear los botones con colores personalizados
	    JButton btnCamisetas = crearBoton("Camisetas", new Color(144, 238, 144), modernFont); // Verde claro
	    JButton btnPañuelos = crearBoton("Pañuelos", new Color(173, 216, 230), modernFont); // Azul claro
	    JButton btnTotebags = crearBoton("Totebags", new Color(255, 182, 193), modernFont); // Rosado claro
	    JButton btnPolos = crearBoton("Polos", new Color(255, 222, 173), modernFont); // Amarillo claro

	    // Agregar los botones al JDialog
	    dialog.add(btnCamisetas);
	    dialog.add(btnPañuelos);
	    dialog.add(btnTotebags);
	    dialog.add(btnPolos);

	    // Acción del botón "Camisetas"
	    btnCamisetas.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            dialog.dispose();
	            frameCamisetas(); // Llamar al método para mostrar la pantalla de camisetas
	        }
	    });

	    // Acción del botón "Pañuelos"
	    btnPañuelos.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            dialog.dispose();
	            framePañuelos(); // Llamar al método para mostrar la pantalla de pañuelos
	        }
	    });

	    // Acción del botón "Totebags"
	    btnTotebags.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            dialog.dispose();
	            frameTotebags(); // Llamar al método para mostrar la pantalla de totebags
	        }
	    });

	    // Acción del botón "Polos"
	    btnPolos.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            dialog.dispose();
	            framePolos(); // Llamar al método para mostrar la pantalla de polos
	        }
	    });

	    // Mostrar el JDialog
	    dialog.setVisible(true);
		
	}
	
	private JButton crearBoton(String texto, Color colorFondo, Font fuente) {
	    JButton boton = new JButton(texto);
	    boton.setFont(fuente);
	    boton.setBackground(colorFondo);
	    boton.setForeground(Color.BLACK);
	    boton.setPreferredSize(new Dimension(150, 40)); // Ajustar el tamaño del botón
	    return boton;
	}
	
	
	private void frameCamisetas() {
		JFrame nuevoFrameCamisetas = new JFrame("Añadir Camiseta");
	    nuevoFrameCamisetas.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    nuevoFrameCamisetas.setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar la ventana
	    nuevoFrameCamisetas.setUndecorated(true); // Eliminar bordes y barra de título
	    nuevoFrameCamisetas.setVisible(true);

	    nuevoFrameCamisetas.getContentPane().setLayout(new GridBagLayout());
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.insets = new Insets(5, 5, 5, 5); // Espacio entre componentes
	    gbc.fill = GridBagConstraints.HORIZONTAL;

	    // Fuente moderna
	    Font modernFont = new Font("Segoe UI", Font.BOLD, 16);

	    // Crear los componentes del formulario
	    JLabel lblTalla = new JLabel("Talla:");
	    lblTalla.setFont(modernFont);
	    JTextField txtTalla = new JTextField(15);

	    JLabel lblColor = new JLabel("Color:");
	    lblColor.setFont(modernFont);
	    JTextField txtColor = new JTextField(15);

	    JLabel lblCantidad = new JLabel("Cantidad:");
	    lblCantidad.setFont(modernFont);
	    JTextField txtCantidad = new JTextField(15);

	    JLabel lblPrecioVenta = new JLabel("Precio Venta:");
	    lblPrecioVenta.setFont(modernFont);
	    JTextField txtPrecioVenta = new JTextField(15);

	    JButton btnGuardar = crearBoton("Guardar", new Color(144, 238, 144), modernFont); // Verde claro
	    JButton btnCancelar = crearBoton("Cancelar", new Color(255, 182, 193), modernFont); // Rosado claro
	    JButton btnVolver = crearBoton("Volver", new Color(173, 216, 230), modernFont); // Azul claro

	    // Agregar los componentes al JFrame con GridBagLayout
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    nuevoFrameCamisetas.getContentPane().add(lblTalla, gbc);

	    gbc.gridx = 1;
	    nuevoFrameCamisetas.getContentPane().add(txtTalla, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 1;
	    nuevoFrameCamisetas.getContentPane().add(lblColor, gbc);

	    gbc.gridx = 1;
	    nuevoFrameCamisetas.getContentPane().add(txtColor, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 2;
	    nuevoFrameCamisetas.getContentPane().add(lblCantidad, gbc);

	    gbc.gridx = 1;
	    nuevoFrameCamisetas.getContentPane().add(txtCantidad, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 3;
	    nuevoFrameCamisetas.getContentPane().add(lblPrecioVenta, gbc);

	    gbc.gridx = 1;
	    nuevoFrameCamisetas.getContentPane().add(txtPrecioVenta, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 4;
	    nuevoFrameCamisetas.getContentPane().add(btnGuardar, gbc);

	    gbc.gridx = 1;
	    nuevoFrameCamisetas.getContentPane().add(btnCancelar, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 5;
	    nuevoFrameCamisetas.getContentPane().add(btnVolver, gbc);

	    // Actualizar visualmente el JFrame
	    nuevoFrameCamisetas.revalidate();
	    nuevoFrameCamisetas.repaint();

	    // Acción del botón "Guardar"
	    btnGuardar.addActionListener(e -> {
	        String talla = txtTalla.getText();
	        String color = txtColor.getText();
	        String precioVentaa = txtPrecioVenta.getText();
	        Double precioVenta = Double.parseDouble(precioVentaa);
	        String canti = txtCantidad.getText();
	        int cantidad = Integer.parseInt(canti);

	        GuardarCamisetas(color, precioVenta, talla, cantidad);
	    });

	    // Acción del botón "Cancelar"
	    btnCancelar.addActionListener(e -> nuevoFrameCamisetas.dispose());

	    // Acción del botón "Volver"
	    btnVolver.addActionListener(e -> nuevoFrameCamisetas.dispose());
		
	}
	

	private void framePañuelos() {
		JFrame nuevoFramePañuelos = new JFrame("Añadir Pañuelo");
	    nuevoFramePañuelos.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    nuevoFramePañuelos.setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar la ventana
	    nuevoFramePañuelos.setUndecorated(true); // Eliminar bordes y barra de título
	    nuevoFramePañuelos.setVisible(true);

	    nuevoFramePañuelos.getContentPane().setLayout(new GridBagLayout());
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.insets = new Insets(5, 5, 5, 5); // Espacio entre componentes
	    gbc.fill = GridBagConstraints.HORIZONTAL;

	    // Fuente moderna
	    Font modernFont = new Font("Segoe UI", Font.BOLD, 16);

	    // Crear los componentes del formulario
	    JLabel lblColor = new JLabel("Color:");
	    lblColor.setFont(modernFont);
	    JTextField txtColor = new JTextField(15);

	    JLabel lblCantidad = new JLabel("Cantidad:");
	    lblCantidad.setFont(modernFont);
	    JTextField txtCantidad = new JTextField(15);

	    JLabel lblPrecioVenta = new JLabel("Precio Venta:");
	    lblPrecioVenta.setFont(modernFont);
	    JTextField txtPrecioVenta = new JTextField(15);

	    JButton btnGuardar = crearBoton("Guardar", new Color(144, 238, 144), modernFont); // Verde claro
	    JButton btnCancelar = crearBoton("Cancelar", new Color(255, 182, 193), modernFont); // Rosado claro
	    JButton btnVolver = crearBoton("Volver", new Color(173, 216, 230), modernFont); // Azul claro

	    // Agregar los componentes al JFrame con GridBagLayout
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    nuevoFramePañuelos.getContentPane().add(lblColor, gbc);

	    gbc.gridx = 1;
	    nuevoFramePañuelos.getContentPane().add(txtColor, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 1;
	    nuevoFramePañuelos.getContentPane().add(lblCantidad, gbc);

	    gbc.gridx = 1;
	    nuevoFramePañuelos.getContentPane().add(txtCantidad, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 2;
	    nuevoFramePañuelos.getContentPane().add(lblPrecioVenta, gbc);

	    gbc.gridx = 1;
	    nuevoFramePañuelos.getContentPane().add(txtPrecioVenta, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 3;
	    nuevoFramePañuelos.getContentPane().add(btnGuardar, gbc);

	    gbc.gridx = 1;
	    nuevoFramePañuelos.getContentPane().add(btnCancelar, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 4;
	    nuevoFramePañuelos.getContentPane().add(btnVolver, gbc);

	    // Actualizar visualmente el JFrame
	    nuevoFramePañuelos.revalidate();
	    nuevoFramePañuelos.repaint();

	    // Acción del botón "Guardar"
	    btnGuardar.addActionListener(e -> {
	        String color = txtColor.getText();
	        String precioVentaa = txtPrecioVenta.getText();
	        Double precioVenta = Double.parseDouble(precioVentaa);
	        String canti = txtCantidad.getText();
	        int cantidad = Integer.parseInt(canti);

	        GuardarPañuelos(color, precioVenta, cantidad);
	    });

	    // Acción del botón "Cancelar"
	    btnCancelar.addActionListener(e -> nuevoFramePañuelos.dispose());

	    // Acción del botón "Volver"
	    btnVolver.addActionListener(e -> nuevoFramePañuelos.dispose());
	}
	
	private void frameTotebags() {
		JFrame nuevoFrameTotebags = new JFrame("Añadir Totebag");
	    nuevoFrameTotebags.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    nuevoFrameTotebags.setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar la ventana
	    nuevoFrameTotebags.setUndecorated(true); // Eliminar bordes y barra de título
	    nuevoFrameTotebags.setVisible(true);

	    nuevoFrameTotebags.getContentPane().setLayout(new GridBagLayout());
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.insets = new Insets(5, 5, 5, 5); // Espacio entre componentes
	    gbc.fill = GridBagConstraints.HORIZONTAL;

	    // Fuente moderna
	    Font modernFont = new Font("Segoe UI", Font.BOLD, 16);

	    // Crear los componentes del formulario
	    JLabel lblColor = new JLabel("Color:");
	    lblColor.setFont(modernFont);
	    JTextField txtColor = new JTextField(15);

	    JLabel lblCantidad = new JLabel("Cantidad:");
	    lblCantidad.setFont(modernFont);
	    JTextField txtCantidad = new JTextField(15);

	    JLabel lblPrecioVenta = new JLabel("Precio Venta:");
	    lblPrecioVenta.setFont(modernFont);
	    JTextField txtPrecioVenta = new JTextField(15);

	    JButton btnGuardar = crearBoton("Guardar", new Color(144, 238, 144), modernFont); // Verde claro
	    JButton btnCancelar = crearBoton("Cancelar", new Color(255, 182, 193), modernFont); // Rosado claro
	    JButton btnVolver = crearBoton("Volver", new Color(173, 216, 230), modernFont); // Azul claro

	    // Agregar los componentes al JFrame con GridBagLayout
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    nuevoFrameTotebags.getContentPane().add(lblColor, gbc);

	    gbc.gridx = 1;
	    nuevoFrameTotebags.getContentPane().add(txtColor, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 1;
	    nuevoFrameTotebags.getContentPane().add(lblCantidad, gbc);

	    gbc.gridx = 1;
	    nuevoFrameTotebags.getContentPane().add(txtCantidad, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 2;
	    nuevoFrameTotebags.getContentPane().add(lblPrecioVenta, gbc);

	    gbc.gridx = 1;
	    nuevoFrameTotebags.getContentPane().add(txtPrecioVenta, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 3;
	    nuevoFrameTotebags.getContentPane().add(btnGuardar, gbc);

	    gbc.gridx = 1;
	    nuevoFrameTotebags.getContentPane().add(btnCancelar, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 4;
	    nuevoFrameTotebags.getContentPane().add(btnVolver, gbc);

	    // Actualizar visualmente el JFrame
	    nuevoFrameTotebags.revalidate();
	    nuevoFrameTotebags.repaint();

	    // Acción del botón "Guardar"
	    btnGuardar.addActionListener(e -> {
	        String color = txtColor.getText();
	        String precioVentaa = txtPrecioVenta.getText();
	        Double precioVenta = Double.parseDouble(precioVentaa);
	        String canti = txtCantidad.getText();
	        int cantidad = Integer.parseInt(canti);

	        GuardarTotebags(color, precioVenta, cantidad);
	    });

	    // Acción del botón "Cancelar"
	    btnCancelar.addActionListener(e -> nuevoFrameTotebags.dispose());

	    // Acción del botón "Volver"
	    btnVolver.addActionListener(e -> nuevoFrameTotebags.dispose());
		
	}

	
	// Método para mostrar la pantalla de polos
	public void framePolos() {
	    JFrame nuevoFramePolos = new JFrame("Añadir Polo");
	    nuevoFramePolos.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    nuevoFramePolos.setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar la ventana
	    nuevoFramePolos.setUndecorated(true); // Eliminar bordes y barra de título
	    nuevoFramePolos.setVisible(true);

	    nuevoFramePolos.getContentPane().setLayout(new GridBagLayout());
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.insets = new Insets(5, 5, 5, 5); // Espacio entre componentes
	    gbc.fill = GridBagConstraints.HORIZONTAL;
	    
	 // Fuente moderna
	    Font modernFont = new Font("Segoe UI", Font.BOLD, 16);

	    // Crear los componentes del formulario
	    JLabel lblTalla = new JLabel("Talla:");
	    lblTalla.setFont(modernFont);
	    
	    JTextField txtTalla = new JTextField(15);
	    
	    JLabel lblColor = new JLabel("Color:");
	    lblColor.setFont(modernFont);
	    
	    JTextField txtColor = new JTextField(15);
	    
	    JLabel lblCantidad = new JLabel("Cantidad:");
	    lblCantidad.setFont(modernFont);
	    
	    JTextField txtCantidad = new JTextField(15);
	    
	    JLabel lblPrecioVenta = new JLabel("Precio Venta:");
	    lblPrecioVenta.setFont(modernFont);
	    
	    JTextField txtPrecioVenta = new JTextField(15);

	    JButton btnGuardar = crearBoton("Guardar", new Color(144, 238, 144), modernFont); // Verde claro
	    JButton btnCancelar = crearBoton("Cancelar", new Color(255, 182, 193), modernFont); // Rosado claro
	    JButton btnVolver = crearBoton("Volver", new Color(173, 216, 230), modernFont); // Azul claro

	    // Agregar los componentes al JFrame con GridBagLayout
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    nuevoFramePolos.getContentPane().add(lblTalla, gbc);

	    gbc.gridx = 1;
	    nuevoFramePolos.getContentPane().add(txtTalla, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 1;
	    nuevoFramePolos.getContentPane().add(lblColor, gbc);

	    gbc.gridx = 1;
	    nuevoFramePolos.getContentPane().add(txtColor, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 2;
	    nuevoFramePolos.getContentPane().add(lblCantidad, gbc);

	    gbc.gridx = 1;
	    nuevoFramePolos.getContentPane().add(txtCantidad, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 3;
	    nuevoFramePolos.getContentPane().add(lblPrecioVenta, gbc);

	    gbc.gridx = 1;
	    nuevoFramePolos.getContentPane().add(txtPrecioVenta, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 4;
	    nuevoFramePolos.getContentPane().add(btnGuardar, gbc);

	    gbc.gridx = 1;
	    nuevoFramePolos.getContentPane().add(btnCancelar, gbc);

	    gbc.gridx = 0;
	    gbc.gridy = 5;
	    nuevoFramePolos.getContentPane().add(btnVolver, gbc);

	    // Actualizar visualmente el JFrame
	    nuevoFramePolos.revalidate();
	    nuevoFramePolos.repaint();

	    // Acción del botón "Guardar"
	    btnGuardar.addActionListener(e -> {
	    	String talla = txtTalla.getText();
	    	String color = txtColor.getText();
	    	String precioVentaa = txtPrecioVenta.getText();
	    	Double precioVenta = Double.parseDouble(precioVentaa);
	    	String canti = txtCantidad.getText();
	    	int cantidad = Integer.parseInt(canti);
	    	
	        GuardarPolos(color, precioVenta, talla, cantidad);
	    });

	    // Acción del botón "Cancelar"
	    btnCancelar.addActionListener(e -> nuevoFramePolos.dispose());

	    // Acción del botón "Volver"
	    btnVolver.addActionListener(e -> nuevoFramePolos.dispose());
	}
	
	private void GuardarCamisetas( String color, double precioVenta, String talla, int cantidad) {
		String tipoo = "Camiseta";
	    int idCamiseta = generarIdPorTalla(talla); // Generar ID basado en la talla

	    String sql = "INSERT INTO merchandising (id_merch, tipo, color, precio_venta, talla, cantidad) VALUES (?, ?, ?, ?, ?, ?)";
	    try (Connection conexion = Conexion.conectar(); PreparedStatement ps = conexion.prepareStatement(sql)) {
	        ps.setInt(1, idCamiseta);
	        ps.setString(2, tipoo);
	        ps.setString(3, color);
	        ps.setDouble(4, precioVenta);
	        ps.setString(5, talla);
	        ps.setInt(6, cantidad);

	        ps.executeUpdate();
	        JOptionPane.showMessageDialog(this, "¡Polo añadido exitosamente!");
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error al guardar el polo: " + e.getMessage());
	        e.printStackTrace();
	    }
	}
	
	private void GuardarPolos(String color, double precioVenta, String talla, int cantidad) {
		String tipoo = "Polo";
	    int idPolo = generarIdPorTallaPolo(talla); // Generar ID basado en la talla

	    String sql = "INSERT INTO merchandising (id_merch, tipo, color, precio_venta, talla, cantidad) VALUES (?, ?, ?, ?, ?, ?)";
	    try (Connection conexion = Conexion.conectar(); PreparedStatement ps = conexion.prepareStatement(sql)) {
	        ps.setInt(1, idPolo);
	        ps.setString(2, tipoo);
	        ps.setString(3, color);
	        ps.setDouble(4, precioVenta);
	        ps.setString(5, talla);
	        ps.setInt(6, cantidad);

	        ps.executeUpdate();
	        JOptionPane.showMessageDialog(this, "¡Camiseta añadida exitosamente!");
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(this, "Error al guardar la camiseta: " + e.getMessage());
	        e.printStackTrace();
	    }
		
	}

	private void GuardarTotebags(String color, double precioVenta, int cantidad) {
		String tipoo = "Totebag";
		String tallaa = "Totebag";
		
		String sql = "INSERT INTO merchandising (tipo, color, precio_venta, talla, cantidad) VALUES (?, ?, ?, ?, ?)";
        try (Connection conexion = Conexion.conectar(); PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, tipoo);
            ps.setString(2, color);
            ps.setDouble(3, precioVenta);
            ps.setString(4, tallaa);
            ps.setInt(5, cantidad);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "¡Totebag añadido exitosamente!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al guardar el totebag: " + e.getMessage());
            e.printStackTrace();
        }
	}

	private void GuardarPañuelos(String color, double precioVenta, int cantidad) {
		String tipoo = "Pañuelo";
		String tallaa = "Pañuelo";
		
		String sql = "INSERT INTO merchandising (tipo, color, precio_venta, talla, cantidad) VALUES (?, ?, ?, ?, ?)";
        try (Connection conexion = Conexion.conectar(); PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, tipoo);
            ps.setString(2, color);
            ps.setDouble(3, precioVenta);
            ps.setString(4, tallaa);
            ps.setInt(5, cantidad);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "¡Pañuelo añadido exitosamente!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al guardar el pañuelo: " + e.getMessage());
            e.printStackTrace();
        }
	}

	
	


	private int generarIdPorTalla(String talla) {
	    int idBase = 0; // Base para los IDs
	    switch (talla) {
	        case "XS":
	            return idBase + 1;
	        case "S":
	            return idBase + 2;
	        case "M":
	            return idBase + 3;
	        case "L":
	            return idBase + 4;
	        case "XL":
	            return idBase + 5;
	        default:
	            return idBase; // ID por defecto si la talla no coincide
	    }
	}
	
	private int generarIdPorTallaPolo(String talla) {
	    int idBase = 5; // Base para los IDs
	    switch (talla) {
	        case "XS":
	            return idBase + 1;
	        case "S":
	            return idBase + 2;
	        case "M":
	            return idBase + 3;
	        case "L":
	            return idBase + 4;
	        case "XL":
	            return idBase + 5;
	        default:
	            return idBase; // ID por defecto si la talla no coincide
	    }
	}
	
	private void mostrarPrendas() {
	    // Crear un panel para mostrar las prendas
	    JPanel panelPrendas = new JPanel();
	    panelPrendas.setLayout(new BorderLayout());
	    panelPrendas.setBackground(new Color(240, 248, 255)); // Fondo azul claro pastel

	    // Crear lista de prendas
	    DefaultListModel<String> model = new DefaultListModel<>();
	    JList<String> listaPrendas = new JList<>(model);
	    listaPrendas.setFont(new Font("Segoe UI", Font.PLAIN, 14));
	    JScrollPane scrollPane = new JScrollPane(listaPrendas);

	    // Botón para eliminar prenda
	    JButton btnEliminar = new JButton("Eliminar Prenda");
	    btnEliminar.setFont(new Font("Segoe UI", Font.BOLD, 14));
	    btnEliminar.setBackground(new Color(255, 182, 193)); // Rosado claro
	    btnEliminar.setEnabled(false); // Deshabilitado inicialmente

	    // Habilitar el botón eliminar al seleccionar un elemento
	    listaPrendas.addListSelectionListener(e -> btnEliminar.setEnabled(!listaPrendas.isSelectionEmpty()));

	    // Recuperar prendas de la base de datos
	    String sql = "SELECT id_merch, tipo, color, talla, cantidad, precio_venta FROM merchandising";

	    try (Connection conexion = Conexion.conectar();
	         PreparedStatement ps = conexion.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {
	            int id = rs.getInt("id_merch");
	            String tipo = rs.getString("tipo");
	            String color = rs.getString("color");
	            String talla = rs.getString("talla");
	            int cantidad = rs.getInt("cantidad");
	            double precioVenta = rs.getDouble("precio_venta");

	            // Formatear cada prenda con sus datos
	            String prenda = "ID: " + id + " | Tipo: " + tipo + " | Color: " + color + " | Talla: " + talla + " | Cantidad: " + cantidad + " | Precio: €" + precioVenta;
	            model.addElement(prenda); // Agregar al modelo de la lista
	        }

	    } catch (Exception ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(this, "Error al recuperar las prendas: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }

	    // Acción para eliminar prenda
	    btnEliminar.addActionListener(e -> {
	        String prendaSeleccionada = listaPrendas.getSelectedValue();
	        if (prendaSeleccionada != null) {
	            int idPrenda = Integer.parseInt(prendaSeleccionada.split(": ")[1].split(" \\|")[0]); // Obtener el ID de la prenda

	            try (Connection conexion = Conexion.conectar();
	                 PreparedStatement ps = conexion.prepareStatement("DELETE FROM merchandising WHERE id_merch = ?")) {

	                ps.setInt(1, idPrenda);

	                int rowsDeleted = ps.executeUpdate();
	                if (rowsDeleted > 0) {
	                    JOptionPane.showMessageDialog(this, "Prenda eliminada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
	                    model.removeElement(prendaSeleccionada); // Eliminar de la lista visual
	                }

	            } catch (Exception ex) {
	                ex.printStackTrace();
	                JOptionPane.showMessageDialog(this, "Error al eliminar la prenda: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	    });

	    // Agregar componentes al panel
	    panelPrendas.add(scrollPane, BorderLayout.CENTER);
	    panelPrendas.add(btnEliminar, BorderLayout.SOUTH);

	    // Mostrar el panel en el centro de la ventana principal
	    contentPane.removeAll(); // Limpiar la ventana principal
	    contentPane.setLayout(new BorderLayout());
	    contentPane.add(panelPrendas, BorderLayout.CENTER);
	    contentPane.revalidate(); // Refrescar el contenido
	    contentPane.repaint(); // Actualizar la interfaz visual
	}
}

