package Eventos;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

public class Mapa extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public Mapa() {
        setTitle("Google Maps Example");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel para el mapa
        JPanel mapPanel = new JPanel();
        mapPanel.setLayout(new BorderLayout());
        add(mapPanel, BorderLayout.CENTER);

        // Aquí iría el código para inicializar y mostrar el mapa de Google Maps
        // usando la API de Google Maps y la clave API generada.
    }

    

}
