package Comisarios;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Menu.VistaMenu;
import SQL.Conexion;

import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;

public class VistaComisarios extends JFrame {

	//private List<String> usuarios;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaComisarios frame = new VistaComisarios();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaComisarios() {

		//usuarios = new ArrayList<>();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		// Crear los elementos del menú
		JMenuItem añadirComisario = new JMenuItem("AÑADIR COMISARIO");
		JMenuItem mostrarComisarios = new JMenuItem("MOSTRAR COMISARIOS");
		//JMenuItem gestionarComisario = new JMenuItem("GESTIONAR COMISARIO");
		menuBar.add(añadirComisario);
		menuBar.add(mostrarComisarios);
		//menuBar.add(gestionarComisario);

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.columnWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
				0.0, Double.MIN_VALUE };
		gbl_contentPane.rowWeights = new double[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE };
		contentPane.setLayout(gbl_contentPane);

		JButton btnVolver = new JButton("VOLVER");
		GridBagConstraints gbc_btnVolver = new GridBagConstraints();
		gbc_btnVolver.gridx = 13;
		gbc_btnVolver.gridy = 6;
		contentPane.add(btnVolver, gbc_btnVolver);

		// Agregar ActionListeners a los elementos del menú
		añadirComisario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mostrar el formulario de añadir usuario
				mostrarFormularioAñadirUsuario();
			}

		});

		// Agregar ActionListeners a los elementos del menú
		mostrarComisarios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Mostrar el formulario de añadir usuario
				mostrarUsuarios();
			}

		});

//		gestionarComisario.addActionListener(new ActionListener() {
//
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				gestionarUsuarios();
//
//			}
//
//		});

		btnVolver.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VistaMenu vistaMenu = new VistaMenu();
				vistaMenu.setVisible(true);
				dispose();

			}

		});
	}

	private void mostrarFormularioAñadirUsuario() {
		// Crear el JDialog para el formulario
		JDialog dialog = new JDialog(this, "Añadir Usuario", true);

		dialog.setUndecorated(true); // Eliminar bordes y barra de título

		// Configurar el tamaño del JDialog para que ocupe toda la pantalla
		dialog.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		dialog.setLocationRelativeTo(null);

		dialog.setSize(500, 300);
		dialog.getContentPane().setLayout(new GridLayout(5, 3));
		dialog.setLocationRelativeTo(this);

		// Crear los componentes del formulario
		JLabel lblNombre = new JLabel("Nombre:");
		JTextField txtNombre = new JTextField();
		JLabel lblApellido = new JLabel("Apellido:");
		JTextField txtApellido = new JTextField();
		JLabel lblTelefono = new JLabel("Telefono:");
		JTextField txtTelefono = new JTextField();

		JButton btnGuardar = new JButton("Guardar");
		JButton btnCancelar = new JButton("Cancelar");

		// Agregar los componentes al JDialog
		dialog.getContentPane().add(lblNombre);
		dialog.getContentPane().add(txtNombre);
		dialog.getContentPane().add(lblApellido);
		dialog.getContentPane().add(txtApellido);
		dialog.getContentPane().add(lblTelefono);
		dialog.getContentPane().add(txtTelefono);
		

		dialog.getContentPane().add(new JLabel()); // Espacio vacío
		dialog.getContentPane().add(btnGuardar);
		dialog.add(btnCancelar);

		// Agregar ActionListener al botón Guardar
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Aquí puedes agregar la lógica para guardar el usuario
				String nombre = txtNombre.getText();
				String apellido = txtApellido.getText();
				String num = txtTelefono.getText();
				int telefono = Integer.parseInt(num);
				
				
				if(guardarUsuario(nombre, apellido, telefono)) {
					JOptionPane.showMessageDialog(dialog, "Usuario añadido: " + nombre + " " + apellido);
					dialog.dispose();
				}else {
					JOptionPane.showMessageDialog(dialog, "Error al añadir el usuario");
					dialog.dispose();
				}

				
			}
		});
		
		// Agregar ActionListener al botón Cancelar
        btnCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.dispose(); // Cerrar el JDialog
            }
        });

		// Mostrar el JDialog
		dialog.setVisible(true);

	}

	private void mostrarUsuarios() {

		String sql = "SELECT * FROM voluntarios";
	    DefaultListModel<String> listModel = new DefaultListModel<>();
	    List<Integer> idsUsuarios = new ArrayList<>(); // Guardará los IDs de los usuarios

	    try (Connection conexion = Conexion.conectar();
	         java.sql.Statement stmt = conexion.createStatement();
	         java.sql.ResultSet rs = stmt.executeQuery(sql)) {

	        while (rs.next()) {
	            int id = rs.getInt("id_voluntario");
	            String nombre = rs.getString("nombre");
	            String apellido = rs.getString("apellido");
	            int telefono = rs.getInt("telefono");

	            listModel.addElement(nombre + " " + apellido + " - Tel: " + telefono);
	            idsUsuarios.add(id); // Guardar ID asociado al usuario
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	        listModel.addElement("Error al obtener los usuarios.");
	    }

	    // Crear el JDialog en pantalla completa
	    JDialog dialog = new JDialog(this, "Lista de Usuarios", true);
	    dialog.setUndecorated(true);
	    dialog.setSize(Toolkit.getDefaultToolkit().getScreenSize());
	    dialog.setLocationRelativeTo(null);

	    // Crear un JList con el modelo y agregarlo a un JScrollPane
	    JList<String> userList = new JList<>(listModel);
	    JScrollPane scrollPane = new JScrollPane(userList);

	    // Botón para eliminar usuario
	    JButton btnEliminar = new JButton("Eliminar Usuario");
	    btnEliminar.addActionListener(e -> {
	        int selectedIndex = userList.getSelectedIndex(); // Obtener el índice seleccionado
	        if (selectedIndex != -1) { // Validar que se haya seleccionado un usuario
	            int confirm = JOptionPane.showConfirmDialog(dialog, "¿Seguro que deseas eliminar este usuario?", 
	                                                        "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
	            if (confirm == JOptionPane.YES_OPTION) {
	                int idUsuario = idsUsuarios.get(selectedIndex); // Obtener el ID del usuario seleccionado
	                if (eliminarUsuario(idUsuario)) { // Intentar eliminar de la BD
	                    listModel.remove(selectedIndex); // Eliminar de la lista si la BD fue exitosa
	                    idsUsuarios.remove(selectedIndex); // También remover el ID de la lista
	                    JOptionPane.showMessageDialog(dialog, "Usuario eliminado con éxito.");
	                } else {
	                    JOptionPane.showMessageDialog(dialog, "Error al eliminar el usuario.");
	                }
	            }
	        } else {
	            JOptionPane.showMessageDialog(dialog, "Selecciona un usuario para eliminar.");
	        }
	    });

	    // Botón para cerrar el diálogo
	    JButton btnCerrar = new JButton("Cerrar");
	    btnCerrar.addActionListener(e -> dialog.dispose());

	    // Panel de botones
	    JPanel buttonPanel = new JPanel();
	    buttonPanel.add(btnEliminar);
	    buttonPanel.add(btnCerrar);

	    // Panel principal
	    JPanel panel = new JPanel(new BorderLayout());
	    panel.add(scrollPane, BorderLayout.CENTER);
	    panel.add(buttonPanel, BorderLayout.SOUTH);

	    dialog.add(panel);
	    dialog.setVisible(true);
	}

//	private void gestionarUsuarios() {
//		// Crear el JDialog para el formulario
//		JDialog dialog = new JDialog(this, "Añadir Usuario", true);
//
//		dialog.setUndecorated(true); // Eliminar bordes y barra de título
//
//		// Configurar el tamaño del JDialog para que ocupe toda la pantalla
//		dialog.setSize(Toolkit.getDefaultToolkit().getScreenSize());
//		dialog.setLocationRelativeTo(null);
//
//		dialog.setSize(600, 400);
//		dialog.getContentPane().setLayout(new GridLayout(5, 3));
//		dialog.setLocationRelativeTo(this);
//
//		// Crear los componentes del formulario
//		JLabel lblNombre = new JLabel("Nombre:");
//		JTextField txtNombre = new JTextField();
//		JLabel lblApellido = new JLabel("Apellido:");
//		JTextField txtApellido = new JTextField();
//		JLabel lblTelefono = new JLabel("Telefono:");
//		JTextField txtTelefono = new JTextField();
//
//		JButton btnGuardar = new JButton("Guardar");
//		JButton btnCancelar = new JButton("Cancelar");
//
//		// Agregar los componentes al JDialog
//		dialog.getContentPane().add(lblNombre);
//		dialog.getContentPane().add(txtNombre);
//		dialog.getContentPane().add(lblApellido);
//		dialog.getContentPane().add(txtApellido);
//		dialog.getContentPane().add(lblTelefono);
//		dialog.getContentPane().add(txtTelefono);
//
//		dialog.getContentPane().add(new JLabel()); // Espacio vacío
//		dialog.getContentPane().add(btnGuardar);
//		dialog.add(btnCancelar);
//
//		// Agregar ActionListener al botón Guardar
//		btnGuardar.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				// Aquí puedes agregar la lógica para guardar el usuario
//				String nombre = txtNombre.getText();
//				String apellido = txtApellido.getText();
//				String num = txtTelefono.getText();
//				int telefono = Integer.parseInt(num);
//				
//				if(guardarUsuario(nombre, apellido, telefono)) {
//					JOptionPane.showMessageDialog(dialog, "Usuario añadido: " + nombre + " " + apellido + " " + telefono );
//					dialog.dispose();
//				}else {
//					JOptionPane.showMessageDialog(dialog, "Error al añadir el usuario");
//					dialog.dispose();
//				}
//
//				
//			}
//		});
//		
//		
//		
//		// Agregar ActionListener al botón Cancelar
//        btnCancelar.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                dialog.dispose(); // Cerrar el JDialog
//            }
//        });
//
//		// Mostrar el JDialog
//		dialog.setVisible(true);
//	}
	
	private boolean guardarUsuario(String nombre, String apellido, int telefono) {
	    String sql = "INSERT INTO voluntarios (nombre, apellido, telefono) VALUES (?, ?, ?)";
	    Comisario comisario = new Comisario(nombre, apellido, telefono);

	    try (Connection conexion = Conexion.conectar();
	         java.sql.PreparedStatement ps = conexion.prepareStatement(sql)) {

	        ps.setString(1, comisario.getNombre());
	        ps.setString(2, comisario.getApellido());
	        ps.setInt(3, comisario.getTelefono());
	        int filasAfectadas = ps.executeUpdate();
	        return filasAfectadas > 0; // Si al menos una fila fue insertada, devuelve true
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }
	}
	
	
	private boolean eliminarUsuario(int id) {
	    String sql = "DELETE FROM voluntarios WHERE id_voluntario = ?";
	    
	    
	    try (Connection conexion = Conexion.conectar();
	         java.sql.PreparedStatement ps = conexion.prepareStatement(sql)) {
	        
	        ps.setInt(1, id);
	        int filasAfectadas = ps.executeUpdate();
	        return filasAfectadas > 0; // Devuelve true si se eliminó correctamente
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }
	}


	
	
}
