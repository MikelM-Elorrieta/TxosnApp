package Menu;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import Comisarios.VistaComisarios;
import Eventos.VistaMenuEventos;
import Inventario.VistaInventario;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaMenu extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    VistaMenu frame = new VistaMenu();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public VistaMenu() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar el JFrame
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(224, 255, 255)); // Azul claro relajante
        setContentPane(contentPane);

        GridBagLayout gbl_contentPane = new GridBagLayout();
        gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0};
        gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0};
        gbl_contentPane.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
        gbl_contentPane.rowWeights = new double[]{1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
        contentPane.setLayout(gbl_contentPane);

        // Fuente moderna
        Font modernFont = new Font("Segoe UI", Font.BOLD, 18);

        // Botón "COMISARIOS"
        JButton btnComisarios = crearBoton("COMISARIOS", new Color(255, 182, 193), new Dimension(200, 60)); // Rosado claro
        GridBagConstraints gbc_btnComisarios = new GridBagConstraints();
        gbc_btnComisarios.insets = new Insets(10, 10, 10, 10); // Espaciado adicional
        gbc_btnComisarios.gridx = 1;
        gbc_btnComisarios.gridy = 1;
        contentPane.add(btnComisarios, gbc_btnComisarios);

        // Botón "INVENTARIO"
        JButton btnInventario = crearBoton("INVENTARIO", new Color(173, 216, 230), new Dimension(200, 60)); // Azul claro
        GridBagConstraints gbc_btnInventario = new GridBagConstraints();
        gbc_btnInventario.insets = new Insets(10, 10, 10, 10);
        gbc_btnInventario.gridx = 2;
        gbc_btnInventario.gridy = 1;
        contentPane.add(btnInventario, gbc_btnInventario);

        // Botón "EVENTOS"
        JButton btnEventos = crearBoton("EVENTOS", new Color(144, 238, 144), new Dimension(200, 60)); // Verde claro
        GridBagConstraints gbc_btnEventos = new GridBagConstraints();
        gbc_btnEventos.insets = new Insets(10, 10, 10, 10);
        gbc_btnEventos.gridx = 3;
        gbc_btnEventos.gridy = 1;
        contentPane.add(btnEventos, gbc_btnEventos);

        // Añadir listeners a los botones
        btnComisarios.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaComisarios vistaComisarios = new VistaComisarios();
                vistaComisarios.setVisible(true);
                dispose();
            }
        });

        btnInventario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaInventario vistaInventario = new VistaInventario();
                vistaInventario.setVisible(true);
                dispose();
            }
        });

        btnEventos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaMenuEventos vistaEventos = new VistaMenuEventos();
                vistaEventos.setVisible(true);
                dispose();
            }
        });
    }

    private JButton crearBoton(String texto, Color colorFondo, Dimension tamaño) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 18));
        boton.setBackground(colorFondo);
        boton.setForeground(Color.BLACK);
        boton.setPreferredSize(tamaño); // Ajustar el tamaño del botón
        return boton;
    }
}